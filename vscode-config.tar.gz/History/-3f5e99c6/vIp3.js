import express from 'express'
import { fstat, readFileSync } from 'fs'
const app = express()
const port = 3000

app.get('/', (req, res) => {

    const file = readFileSync('./measurements.txt', {encoding: 'utf-8'})
    const lines = file.split('\n')
    const lineCount = lines.length
    const map = new Map()
    
    for(let i = 0; i < lineCount; i++) {
        let [name, temp] = lines[i].split(';')
        temp = parseFloat(temp.split('.')[0] + '.' + temp.split('.')[1])
        const obj = {
            name: name,
            tempT: [temp],
            temp: temp,
            total: 1,
            min: 10000,
            max: -10000
        }
        if(map.get(name)) {
            
            let curr = map.get(name)
            curr.tempT.push(temp)
            curr.temp += temp
            curr.total++
            curr.min = Math.min(curr.min, temp)
            curr.max = Math.max(curr.max, temp)
            map.set(name, curr)
        }
        else {
            map.set(name, obj)
        }   
    }

    for (const temperat of map) {
       
       let map1 = new Map()
       for(const temperatura of temperat[1].tempT) {
            
            if(map1.get(temperatura)) {
                const atual = map1.get(temperatura)
                map1.set(temperatura, atual + 1)
            } else {
                map1.set(temperatura, 1)

            }
       }
       
       const maxv = Array.from(map1).sort((a,b) => a[1] - b[1])[0]
       
       temperat[1].moda = maxv[0]
    
       temperat[1].media = temperat[1].temp / temperat[1].total 
    }

    const arr2 = Array.from(map)
    res.json(arr2)
})

app.get('/station/:StationName', (req, res) =>  {
    req.params.StationName
    const file = readFileSync('./measurements.txt', {encoding: 'utf-8'})
    const lines = file.split('\n')
    const lineCount = lines.length
    let arr = []
    let count = 0

    for(let i = 0; i < lineCount; i++) {
        let [name, temp] = lines[i].split(';')
        let obj = {}
        if(lines[i].includes(req.params.StationName)) {
            obj.name = name
            obj.temp = temp
            arr[count] = obj
            count++
        }
    }
    res.send(arr)
})

app.get('/temperatura/:foda', (req, res) => {
    req.params.foda
    res.send('de foder hein')
})

app.listen(port, () => {
    console.log(`Teste`)
})