import path from 'node:path';

import express, {
    Application,
    ErrorRequestHandler,
    NextFunction,
    Request,
    Response,
} from 'express';
import swaggerUi from 'swagger-ui-express';
import { Tspec } from 'tspec';
import { app } from './app';
import { ALGO_URL, API_ACCESS_TOKEN, BACKEND_URL, PORT } from './constants';
import { connection as DBconnection } from './db';
import { LOG } from './lib/Console';
import { ErrorHandler } from './lib/ErrorHandling/ErrorHandler';
import { WebhookInstance, webhook } from './lib/events/Webhooks';
import './process';
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
//@ts-ignore
import swaggerdocs from './docs/openapi.json';
import { trace } from 'node:console';

export const connection = DBconnection;

export const tspecParams: Tspec.GenerateParams = {
    openapi: {
        title: 'Cubo Backend',
        version: '0.1.1',
        servers: [{ url: BACKEND_URL }],
        securityDefinitions: {
            jwt: {
                type: 'http',
                scheme: 'bearer',
                bearerFormat: 'JWT',
            },
        },
    },
};

initServer(app);

function initWebhooks() {
    const algoHeaders = new Headers();

    algoHeaders.append('Content-Type', 'application/json');
    algoHeaders.append('Authorization', `Bearer ${API_ACCESS_TOKEN}`);
    webhook.Add(
        new WebhookInstance(
            {
                headers: algoHeaders,
                url: `${ALGO_URL}/webhook`,
            },
            ['*'],
        ),
    );
}

function initDocs(app: express.Application) {
    app.use(express.static(__dirname));
    app.use('*.css', (_, res, next) => {
        res.set('Content-Type', 'text/css');
        next();
    });
    app.use('/docs/styles', express.static(path.join(__dirname, 'src/docs')));
    app.use(
        '/docs',
        swaggerUi.serve,
        swaggerUi.setup(swaggerdocs, {
            customCssUrl: './styles.css',
            customSiteTitle: 'Cubo Backend Api',
        }),
    );
}

function initServer(app?: Application) {
    if (!app) return;

    const EFunction: ErrorRequestHandler = (
        err: Error,
        __: Request,
        res: Response,
        //!AAAAAAAAAAAAAAAAAAAA DO NOT REMOVE THIS
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        ___: NextFunction,
    ) => {
        ErrorHandler.handle(err, res);
    };
    app.use(EFunction);

    // eslint-disable-next-line require-await
    app.listen(PORT, async () => {
        console.clear();
        LOG.success(`Server is running in http://localhost:${PORT}`);

        
LOG.init()

        initDocs(app);
        initWebhooks();
    });
}
