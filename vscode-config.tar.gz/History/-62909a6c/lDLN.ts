import { App } from '__tests__/vitest.setup';
import { TESTING_ACCESS_TOKEN } from 'src/constants';
import { connection } from 'src/db';
import { HTTPCodes } from 'src/lib/ErrorHandling/ErrorHandler';
import { describe, expect, it } from 'vitest';
import { Order } from 'wecubedigital';

describe('tests the api marketplace dashboard sellers', () => {
     it('GET - sellers', async () => {
          const response = await App.get(
               '/api/dashboard/marketplaces/campaigns/sellers'
          ).set('Authorization', TESTING_ACCESS_TOKEN);

          expect(response.body.data.length).toEqual(response.body.info.total);
          expect(response.body.info.total).toBeGreaterThan(0);
          expect(response.body.data[0]).toBeTypeOf('object');
          expect(response.status).toEqual(HTTPCodes.OK);

          const sellerBalances = await connection('seller_funds').whereIn(
               'id',
               response.body.data.map((seller: { id: number }) => seller.id)
          );

          const sellerCampaigns = await connection('orders')
          .sum('isActive AS active')
          .select('sellerID')
          .groupBy('sellerId') satisfies (Pick<Order, 'sellerId'> & { active : number})[]

          console.log(sellerCampaigns)

          const sellerEarnings = await connection('orders')
          .sum('value as earnings')
          .select('sellerId')
          .groupBy('sellerId') satisfies (Pick<Order, 'sellerId'> & {
               earnings : number
          })[]

          for (let i = 0; i < response.body.data.length; i++) {
               const seller = response.body.data[i];
               expect(seller).toBeDefined();
               assert.ok(seller);

               const balance = sellerBalances.find(
                    (currentSeller) => currentSeller.id === seller.id
               );
               const earnings = sellerEarnings.find(
                    (currentSeller) => currentSeller.sellerId === seller.id
               )
               expect(balance).toBeDefined()
               expect(earnings).toBeDefined()
               assert.ok(balance);
               assert.ok(earnings)

               const investedBalance = parseFloat(String(balance.balance)).toFixed(
                    8
               );
               const investedBody = parseFloat(
                    String(response.body.data[i].invested)
               ).toFixed(8);

               const earningsQuery = parseFloat(String(earnings.earnings)).toFixed(8)
               const earningsBody = parseFloat(String(response.body.data[i].earnings)).toFixed(8)

               let manualCr = response.body.data[i].sold / response.body.data[i].views
               if (isNaN(manualCr)) {
                    manualCr = 0
               }
               let manualCtr = response.body.data[i].clicks / response.body.data[i].views
               if (isNaN(manualCtr)) {
                    manualCtr = 0
               }

               expect(earningsBody).toEqual(earningsQuery)
               expect(investedBalance).toEqual(investedBody);
               expect(response.body.data[i].cr).toEqual(
                    manualCr
               );
               expect(response.body.data[i].ctr).toEqual(
                    manualCtr
               );
          }
     });
});
