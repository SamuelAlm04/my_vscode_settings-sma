import { ObjectValues } from "./types";
export declare const RoleNames: readonly ["admin", "general", "dev", "permissions"];
export type RoleNames = (typeof RoleNames)[number];
export declare const ADMIN_ROLE_PERMISSIONS: {
    readonly ADMIN: {
        readonly path: "admin.isAdmin";
        readonly display_name: "Admin";
        readonly id: 23;
    };
};
export declare const DEV_ROLE_PERMISSIONS: {
    readonly DEV: {
        readonly path: "dev.isDev";
        readonly display_name: "Dev";
        readonly id: 24;
    };
    readonly canAccessTestingEnvironment: {
        readonly path: "dev.canAccessTestingEnvironment";
        readonly display_name: "canAccessTestingEnvironment";
        readonly id: 22;
    };
};
export declare const GENERAL_ROLE_PERMISSIONS: {
    readonly CAMPAIGN: {
        readonly path: "campaign.campaign";
        readonly display_name: "Campaigns";
        readonly id: 1;
    };
    readonly SKU: {
        readonly path: "sku.sku";
        readonly display_name: "sku";
        readonly id: 2;
    };
    readonly SKU_SPECIFICATION: {
        readonly path: "sku_specification.sku_specification";
        readonly display_name: "sku_specification";
        readonly id: 3;
    };
    readonly SKU_KIT: {
        readonly path: "sku_kit.sku_kit";
        readonly display_name: "sku_kit";
        readonly id: 4;
    };
    readonly SKU_INVENTORY: {
        readonly path: "sku_inventory.sku_inventory";
        readonly display_name: "sku_inventory";
        readonly id: 5;
    };
    readonly SKU_FILE: {
        readonly path: "sku_file.sku_file";
        readonly display_name: "sku_file";
        readonly id: 6;
    };
    readonly SKU_ATTACHMENT: {
        readonly path: "sku_attachment.sku_attachment";
        readonly display_name: "sku_attachment";
        readonly id: 7;
    };
    readonly Sku_price: {
        readonly path: "sku_price.sku_price";
        readonly display_name: "sku_price";
        readonly id: 8;
    };
    readonly AD: {
        readonly path: "ads.ads";
        readonly display_name: "ads";
        readonly id: 9;
    };
    readonly CATEGORY: {
        readonly path: "category.category";
        readonly display_name: "category";
        readonly id: 10;
    };
    readonly CATEGORY_SPECIFICATION: {
        readonly path: "category_specification.category_specification";
        readonly display_name: "category_specification";
        readonly id: 11;
    };
    readonly PRODUCT: {
        readonly path: "product.product";
        readonly display_name: "product";
        readonly id: 12;
    };
    readonly MARKETPLACES: {
        readonly path: "marketplaces.marketplaces";
        readonly display_name: "marketplaces";
        readonly id: 13;
    };
    readonly PRODUCT_SPECIFICATION: {
        readonly path: "product_specification.product_specification";
        readonly display_name: "product_specification";
        readonly id: 14;
    };
    readonly BRAND: {
        readonly path: "brand.brand";
        readonly display_name: "brand";
        readonly id: 15;
    };
    readonly BRAND_SPECIFICATION: {
        readonly path: "brand_specification.brand_specification";
        readonly display_name: "brand_specification";
        readonly id: 16;
    };
    readonly ATTACHMENT: {
        readonly path: "attachment.attachment";
        readonly display_name: "attachment";
        readonly id: 17;
    };
    readonly GET_DELETED: {
        readonly path: "items.getDeletedItems";
        readonly display_name: "getDeletedItems";
        readonly id: 18;
    };
    readonly ROLE: {
        readonly path: "role.role";
        readonly display_name: "role";
        readonly id: 19;
    };
    readonly UPDATE_BASE_ROLE: {
        readonly path: "role.update-base-role";
        readonly display_name: "update-base-role";
        readonly id: 20;
    };
    readonly ACTIVATE_PUPELINE: {
        readonly path: "pipeline.activate";
        readonly display_name: "activate-pipeline";
        readonly id: 21;
    };
};
export declare const RolePermission: {
    readonly DEV: {
        readonly path: "dev.isDev";
        readonly display_name: "Dev";
        readonly id: 24;
    };
    readonly canAccessTestingEnvironment: {
        readonly path: "dev.canAccessTestingEnvironment";
        readonly display_name: "canAccessTestingEnvironment";
        readonly id: 22;
    };
    readonly ADMIN: {
        readonly path: "admin.isAdmin";
        readonly display_name: "Admin";
        readonly id: 23;
    };
    readonly CAMPAIGN: {
        readonly path: "campaign.campaign";
        readonly display_name: "Campaigns";
        readonly id: 1;
    };
    readonly SKU: {
        readonly path: "sku.sku";
        readonly display_name: "sku";
        readonly id: 2;
    };
    readonly SKU_SPECIFICATION: {
        readonly path: "sku_specification.sku_specification";
        readonly display_name: "sku_specification";
        readonly id: 3;
    };
    readonly SKU_KIT: {
        readonly path: "sku_kit.sku_kit";
        readonly display_name: "sku_kit";
        readonly id: 4;
    };
    readonly SKU_INVENTORY: {
        readonly path: "sku_inventory.sku_inventory";
        readonly display_name: "sku_inventory";
        readonly id: 5;
    };
    readonly SKU_FILE: {
        readonly path: "sku_file.sku_file";
        readonly display_name: "sku_file";
        readonly id: 6;
    };
    readonly SKU_ATTACHMENT: {
        readonly path: "sku_attachment.sku_attachment";
        readonly display_name: "sku_attachment";
        readonly id: 7;
    };
    readonly Sku_price: {
        readonly path: "sku_price.sku_price";
        readonly display_name: "sku_price";
        readonly id: 8;
    };
    readonly AD: {
        readonly path: "ads.ads";
        readonly display_name: "ads";
        readonly id: 9;
    };
    readonly CATEGORY: {
        readonly path: "category.category";
        readonly display_name: "category";
        readonly id: 10;
    };
    readonly CATEGORY_SPECIFICATION: {
        readonly path: "category_specification.category_specification";
        readonly display_name: "category_specification";
        readonly id: 11;
    };
    readonly PRODUCT: {
        readonly path: "product.product";
        readonly display_name: "product";
        readonly id: 12;
    };
    readonly MARKETPLACES: {
        readonly path: "marketplaces.marketplaces";
        readonly display_name: "marketplaces";
        readonly id: 13;
    };
    readonly PRODUCT_SPECIFICATION: {
        readonly path: "product_specification.product_specification";
        readonly display_name: "product_specification";
        readonly id: 14;
    };
    readonly BRAND: {
        readonly path: "brand.brand";
        readonly display_name: "brand";
        readonly id: 15;
    };
    readonly BRAND_SPECIFICATION: {
        readonly path: "brand_specification.brand_specification";
        readonly display_name: "brand_specification";
        readonly id: 16;
    };
    readonly ATTACHMENT: {
        readonly path: "attachment.attachment";
        readonly display_name: "attachment";
        readonly id: 17;
    };
    readonly GET_DELETED: {
        readonly path: "items.getDeletedItems";
        readonly display_name: "getDeletedItems";
        readonly id: 18;
    };
    readonly ROLE: {
        readonly path: "role.role";
        readonly display_name: "role";
        readonly id: 19;
    };
    readonly UPDATE_BASE_ROLE: {
        readonly path: "role.update-base-role";
        readonly display_name: "update-base-role";
        readonly id: 20;
    };
    readonly ACTIVATE_PUPELINE: {
        readonly path: "pipeline.activate";
        readonly display_name: "activate-pipeline";
        readonly id: 21;
    };
    readonly SHELF: {
        readonly path: "shelf.shelf";
        readonly display_name: "shelf";
        readonly id: 25;
    };
};
export type RolePermission = ObjectValues<typeof RolePermission>;
export declare const PermissionPath: ("campaign.campaign" | "sku.sku" | "sku_specification.sku_specification" | "sku_kit.sku_kit" | "sku_inventory.sku_inventory" | "sku_file.sku_file" | "sku_attachment.sku_attachment" | "sku_price.sku_price" | "ads.ads" | "category.category" | "category_specification.category_specification" | "product.product" | "marketplaces.marketplaces" | "product_specification.product_specification" | "brand.brand" | "brand_specification.brand_specification" | "attachment.attachment" | "items.getDeletedItems" | "role.role" | "role.update-base-role" | "pipeline.activate" | "admin.isAdmin" | "dev.isDev" | "dev.canAccessTestingEnvironment" | "shelf.shelf")[];
export declare const PermissionId: (1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 23 | 24 | 22 | 25)[];
export type RolePermissionsPath = (typeof PermissionPath)[number];
export type RolePermissionsIds = (typeof PermissionId)[number];
export type RolePermissionsRecord = {
    path: string;
    display_name: string;
    id: number;
};
export type RolePermissions = {
    [x in RolePermissionsPath]?: unknown;
};
//# sourceMappingURL=Permissions.d.ts.map