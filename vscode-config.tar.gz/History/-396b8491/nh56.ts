import { z } from 'zod';
export declare const ResponseSchemas: {
    readonly CampaignCreationSku: z.ZodObject<{
        id: z.ZodNumber;
        sellingPrice: z.ZodNumber;
        listPrice: z.ZodNumber;
        availableQuantity: z.ZodNumber;
        productId: z.ZodNumber;
        previousId: z.ZodNumber;
        images: z.ZodArray<z.ZodObject<{
            skuId: z.ZodNumber;
            isMain: z.ZodUnion<[z.ZodNumber, z.ZodBoolean]>;
            url: z.ZodString;
        }, "strip", z.ZodTypeAny, {
            skuId: number;
            isMain: number | boolean;
            url: string;
        }, {
            skuId: number;
            isMain: number | boolean;
            url: string;
        }>, "many">;
    }, "strip", z.ZodTypeAny, {
        id: number;
        previousId: number;
        productId: number;
        listPrice: number;
        sellingPrice: number;
        availableQuantity: number;
        images: {
            skuId: number;
            isMain: number | boolean;
            url: string;
        }[];
    }, {
        id: number;
        previousId: number;
        productId: number;
        listPrice: number;
        sellingPrice: number;
        availableQuantity: number;
        images: {
            skuId: number;
            isMain: number | boolean;
            url: string;
        }[];
    }>;
    readonly CampaignCreationProduct: z.ZodObject<{
        id: z.ZodNumber;
        name: z.ZodOptional<z.ZodString>;
        title: z.ZodUnion<[z.ZodOptional<z.ZodString>, z.ZodNull]>;
        brandId: z.ZodNumber;
        status: z.ZodNumber;
        categoryId: z.ZodNumber;
        linkId: z.ZodOptional<z.ZodString>;
        refId: z.ZodUnion<[z.ZodOptional<z.ZodString>, z.ZodNull]>;
        skus: z.ZodArray<z.ZodObject<{
            id: z.ZodNumber;
            sellingPrice: z.ZodNumber;
            listPrice: z.ZodNumber;
            availableQuantity: z.ZodNumber;
            productId: z.ZodNumber;
            previousId: z.ZodNumber;
            images: z.ZodArray<z.ZodObject<{
                skuId: z.ZodNumber;
                isMain: z.ZodUnion<[z.ZodNumber, z.ZodBoolean]>;
                url: z.ZodString;
            }, "strip", z.ZodTypeAny, {
                skuId: number;
                isMain: number | boolean;
                url: string;
            }, {
                skuId: number;
                isMain: number | boolean;
                url: string;
            }>, "many">;
        }, "strip", z.ZodTypeAny, {
            id: number;
            previousId: number;
            productId: number;
            listPrice: number;
            sellingPrice: number;
            availableQuantity: number;
            images: {
                skuId: number;
                isMain: number | boolean;
                url: string;
            }[];
        }, {
            id: number;
            previousId: number;
            productId: number;
            listPrice: number;
            sellingPrice: number;
            availableQuantity: number;
            images: {
                skuId: number;
                isMain: number | boolean;
                url: string;
            }[];
        }>, "many">;
    }, "strip", z.ZodTypeAny, {
        id: number;
        status: number;
        categoryId: number;
        brandId: number;
        skus: {
            id: number;
            previousId: number;
            productId: number;
            listPrice: number;
            sellingPrice: number;
            availableQuantity: number;
            images: {
                skuId: number;
                isMain: number | boolean;
                url: string;
            }[];
        }[];
        name?: string | undefined;
        linkId?: string | undefined;
        refId?: string | null | undefined;
        title?: string | null | undefined;
    }, {
        id: number;
        status: number;
        categoryId: number;
        brandId: number;
        skus: {
            id: number;
            previousId: number;
            productId: number;
            listPrice: number;
            sellingPrice: number;
            availableQuantity: number;
            images: {
                skuId: number;
                isMain: number | boolean;
                url: string;
            }[];
        }[];
        name?: string | undefined;
        linkId?: string | undefined;
        refId?: string | null | undefined;
        title?: string | null | undefined;
    }>;
    readonly CampaignCreation: z.ZodArray<z.ZodObject<{
        id: z.ZodNumber;
        name: z.ZodOptional<z.ZodString>;
        title: z.ZodUnion<[z.ZodOptional<z.ZodString>, z.ZodNull]>;
        brandId: z.ZodNumber;
        status: z.ZodNumber;
        categoryId: z.ZodNumber;
        linkId: z.ZodOptional<z.ZodString>;
        refId: z.ZodUnion<[z.ZodOptional<z.ZodString>, z.ZodNull]>;
        skus: z.ZodArray<z.ZodObject<{
            id: z.ZodNumber;
            sellingPrice: z.ZodNumber;
            listPrice: z.ZodNumber;
            availableQuantity: z.ZodNumber;
            productId: z.ZodNumber;
            previousId: z.ZodNumber;
            images: z.ZodArray<z.ZodObject<{
                skuId: z.ZodNumber;
                isMain: z.ZodUnion<[z.ZodNumber, z.ZodBoolean]>;
                url: z.ZodString;
            }, "strip", z.ZodTypeAny, {
                skuId: number;
                isMain: number | boolean;
                url: string;
            }, {
                skuId: number;
                isMain: number | boolean;
                url: string;
            }>, "many">;
        }, "strip", z.ZodTypeAny, {
            id: number;
            previousId: number;
            productId: number;
            listPrice: number;
            sellingPrice: number;
            availableQuantity: number;
            images: {
                skuId: number;
                isMain: number | boolean;
                url: string;
            }[];
        }, {
            id: number;
            previousId: number;
            productId: number;
            listPrice: number;
            sellingPrice: number;
            availableQuantity: number;
            images: {
                skuId: number;
                isMain: number | boolean;
                url: string;
            }[];
        }>, "many">;
    }, "strip", z.ZodTypeAny, {
        id: number;
        status: number;
        categoryId: number;
        brandId: number;
        skus: {
            id: number;
            previousId: number;
            productId: number;
            listPrice: number;
            sellingPrice: number;
            availableQuantity: number;
            images: {
                skuId: number;
                isMain: number | boolean;
                url: string;
            }[];
        }[];
        name?: string | undefined;
        linkId?: string | undefined;
        refId?: string | null | undefined;
        title?: string | null | undefined;
    }, {
        id: number;
        status: number;
        categoryId: number;
        brandId: number;
        skus: {
            id: number;
            previousId: number;
            productId: number;
            listPrice: number;
            sellingPrice: number;
            availableQuantity: number;
            images: {
                skuId: number;
                isMain: number | boolean;
                url: string;
            }[];
        }[];
        name?: string | undefined;
        linkId?: string | undefined;
        refId?: string | null | undefined;
        title?: string | null | undefined;
    }>, "many">;
};
