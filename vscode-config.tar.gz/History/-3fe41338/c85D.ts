import { App } from '__tests__/vitest.setup';
import {
    TESTING_ACCESS_TOKEN,
    DEFAULTS,
    API_ACCESS_TOKEN,
} from 'src/constants';
import { connection } from 'src/db';
import { HTTPCodes } from 'src/lib/ErrorHandling/ErrorHandler';
import { Formatter } from 'src/lib/Formatter';
import { describe, expect, it } from 'vitest';
import {
    CAMPAIGN_PLACEMENT,
    ItemStatus,
    CAMPAIGN_TYPES,
    MARKETPLACES,
    ShelfInfo,
} from 'wecubedigital';

const NewShelfObject = {
    name: '',
    section: CAMPAIGN_PLACEMENT.DEPARTMENT_CATEGORY,
    status: ItemStatus.ACTIVE,
    isActive: true,
    marketplaceId: '',
    type: CAMPAIGN_TYPES.SPONSORED_PRODUCTS,
    quantity: 3,
    minCpc: 35,
    orientation: 'horizontal',
    minBudget: 5,
    minDailyBudget: 2,
    metadata: {
        bannerId: 2
    },
    placement: 1, 
    // config: {
    //     addons: ['add_cart'],
    // },
};

describe.todo('tests some stuff');

describe('tests the shelf router', () => {
    it('gets all', async () => {
        const response = await App.get('/shelf').set(
            'Authorization',
            `Bearer ${TESTING_ACCESS_TOKEN}`,
        );
        expect(response.status, 'the route should be defined').not.equal(404);
        expect(response.status, 'there cannot have any internal errors').equal(
            HTTPCodes.OK,
        );
        expect(response.body).toBeDefined();
        expect(response.body).toBeTypeOf('object');
        expect(response.body.length).greaterThan(0);

        for (const shelf of response.body) {
            expect(shelf.id, 'it has to have an id').toBeDefined();
            expect(shelf.id).toBeTypeOf('number');

            expect(shelf.name, 'it has to have an name').toBeDefined();
            expect(shelf.name).toBeTypeOf('string');

            expect(shelf.section).toBeDefined();
            expect(shelf.section).toBeTypeOf('number');
            expect(
                shelf.section ===
                    CAMPAIGN_PLACEMENT.DEPARTMENT_CATEGORY ||
                    shelf.section === CAMPAIGN_PLACEMENT.HOME ||
                    shelf.section === CAMPAIGN_PLACEMENT.PRODUCT ||
                    shelf.section === CAMPAIGN_PLACEMENT.SEARCH_RESULTS,
            ).toEqual(true);
            expect(shelf.status).toBeDefined();
            expect(shelf.status).toBeTypeOf('number');
            expect(Formatter.isValidStatus(shelf.status)).eq(true);

            expect(shelf.isActive).toBeDefined();
            if (typeof shelf.isActive === 'number') {
                expect(shelf.isActive === 1 || shelf.isActive === 0).toEqual(
                    true,
                );
            } else if (typeof shelf.isActive === 'boolean') {
                expect(shelf.isActive).toBeTypeOf('boolean');
            } else {
                expect(1).eq(0);
            }

            expect(shelf.marketplaceId).toBeDefined();
            expect(shelf.marketplaceId).toBeTypeOf('string');
            expect(shelf.marketplaceId).eq(MARKETPLACES.TESTING);

            expect(shelf.type).toBeDefined();
            expect(shelf.type).toBeTypeOf('number');
            expect(Formatter.isInEnum(shelf.type, CAMPAIGN_TYPES));

            expect(shelf.quantity).toBeDefined();
            expect(shelf.quantity).toBeTypeOf('number');
            expect(shelf.quantity).greaterThan(0);

            expect(shelf.minCpc).toBeDefined();
            expect(shelf.minCpc).toBeTypeOf('number');
            expect(shelf.minCpc).greaterThan(
                DEFAULTS.MARKETPLACE_PAYMENT.MIN_CPC,
            );

            expect(shelf.orientation).toBeDefined();
            expect(shelf.orientation).toBeTypeOf('string');

            expect(shelf.minBudget).toBeDefined();
            expect(shelf.minBudget).toBeTypeOf('number');
            expect(shelf.minBudget).greaterThan(0);

            expect(shelf.minDailyBudget).toBeDefined();
            expect(shelf.minDailyBudget).toBeTypeOf('number');
            expect(shelf.minDailyBudget).greaterThan(0);

            // expect(shelf.config).toBeDefined();
            // expect(
            //     typeof shelf.config === 'string' ||
            //         typeof shelf.config === 'object',
            // );

            // const config =
            //     typeof shelf.config === 'string'
            //         ? JSON.parse(shelf.config)
            //         : shelf.config;

            // expect(config).toHaveProperty('addons');
        }
    });
    it('can get one ', async () => {
        let shelf: ShelfInfo | undefined;
        try {
            shelf = await connection('shelf')
                .where('marketplaceId', MARKETPLACES.TESTING)
                .first();
        } catch (err) {
            logger.error('invalid parse', err);
            expect(shelf).toBeDefined();
        }
        assert.ok(shelf);

        const response = await App.get(`/shelf/${shelf.id}`).set(
            'Authorization',
            `Bearer ${TESTING_ACCESS_TOKEN}`,
        );

        expect(response.status, 'the route should be defined').not.eq(404);
        expect(response.status).eq(200);
        expect(response.body.id, 'it has to have an id').toBeDefined();
        expect(response.body.id).toBeTypeOf('number');

        expect(response.body.name, 'it has to have an name').toBeDefined();
        expect(response.body.name).toBeTypeOf('string');

        expect(response.body.section).toBeDefined();
        expect(response.body.section).toBeTypeOf('number');
        expect(
            response.body.section ===
                CAMPAIGN_PLACEMENT.DEPARTMENT_CATEGORY ||
                response.body.section === CAMPAIGN_PLACEMENT.HOME ||
                response.body.section === CAMPAIGN_PLACEMENT.PRODUCT ||
                response.body.section === CAMPAIGN_PLACEMENT.SEARCH_RESULTS,
        ).toEqual(true);
        expect(response.body.status).toBeDefined();
        expect(response.body.status).toBeTypeOf('number');
        expect(Formatter.isValidStatus(response.body.status)).eq(true);

        expect(response.body.isActive).toBeDefined();
        if (typeof response.body.isActive === 'number') {
            expect(
                response.body.isActive === 1 || response.body.isActive === 0,
            ).toEqual(true);
        } else if (typeof response.body.isActive === 'boolean') {
            expect(response.body.isActive).toBeTypeOf('boolean');
        } else {
            expect(1).eq(0);
        }

        expect(response.body.marketplaceId).toBeDefined();
        expect(response.body.marketplaceId).toBeTypeOf('string');
        expect(response.body.marketplaceId).eq(MARKETPLACES.TESTING);

        expect(response.body.type).toBeDefined();
        expect(response.body.type).toBeTypeOf('number');
        expect(Formatter.isInEnum(response.body.type, CAMPAIGN_TYPES));

        expect(response.body.quantity).toBeDefined();
        expect(response.body.quantity).toBeTypeOf('number');
        expect(response.body.quantity).greaterThan(0);

        expect(response.body.minCpc).toBeDefined();
        expect(response.body.minCpc).toBeTypeOf('number');
        expect(response.body.minCpc).greaterThan(
            DEFAULTS.MARKETPLACE_PAYMENT.MIN_CPC,
        );

        expect(response.body.orientation).toBeDefined();
        expect(response.body.orientation).toBeTypeOf('string');

        expect(response.body.minBudget).toBeDefined();
        expect(response.body.minBudget).toBeTypeOf('number');
        expect(response.body.minBudget).greaterThan(0);

        expect(response.body.minDailyBudget).toBeDefined();
        expect(response.body.minDailyBudget).toBeTypeOf('number');
        expect(response.body.minDailyBudget).greaterThan(0);

        // expect(response.body.config).toBeDefined();
        // expect(
        //     typeof response.body.config === 'string' ||
        //         typeof response.body.config === 'object',
        // );

        // const config =
        //     typeof response.body.config === 'string'
        //         ? JSON.parse(response.body.config)
        //         : response.body.config;

        // expect(config).toHaveProperty('addons');
    });

    it.only('can post one', async () => {
        const response = await App.post('/shelf')
            .send(NewShelfObject)
            .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

        expect(response.status, 'the route should be defined').not.eq(404);
        expect(response.status).eq(200);
        expect(response.body.id, 'it has to have an id').toBeDefined();
        expect(response.body.id).toBeTypeOf('number');

        expect(response.body.name, 'it has to have an name').toBeDefined();
        expect(response.body.name).toBeTypeOf('string');

        expect(response.body.section).toBeDefined();
        expect(response.body.section).toBeTypeOf('number');
        expect(
            response.body.section ===
                CAMPAIGN_PLACEMENT.DEPARTMENT_CATEGORY ||
                response.body.section === CAMPAIGN_PLACEMENT.HOME ||
                response.body.section === CAMPAIGN_PLACEMENT.PRODUCT ||
                response.body.section === CAMPAIGN_PLACEMENT.SEARCH_RESULTS,
        ).toEqual(true);
        expect(response.body.status).toBeDefined();
        expect(response.body.status).toBeTypeOf('number');
        expect(Formatter.isValidStatus(response.body.status)).eq(true);

        expect(response.body.isActive).toBeDefined();
        if (typeof response.body.isActive === 'number') {
            expect(
                response.body.isActive === 1 || response.body.isActive === 0,
            ).toEqual(true);
        } else if (typeof response.body.isActive === 'boolean') {
            expect(response.body.isActive).toBeTypeOf('boolean');
        } else {
            expect(1).eq(0);
        }

        expect(response.body.marketplaceId).toBeDefined();
        expect(response.body.marketplaceId).toBeTypeOf('string');
        expect(response.body.marketplaceId).eq(MARKETPLACES.TESTING);

        expect(response.body.type).toBeDefined();
        expect(response.body.type).toBeTypeOf('number');
        expect(Formatter.isInEnum(response.body.type, CAMPAIGN_TYPES));

        expect(response.body.quantity).toBeDefined();
        expect(response.body.quantity).toBeTypeOf('number');
        expect(response.body.quantity).greaterThan(0);

        expect(response.body.minCpc).toBeDefined();
        expect(response.body.minCpc).toBeTypeOf('number');
        expect(response.body.minCpc).greaterThan(
            DEFAULTS.MARKETPLACE_PAYMENT.MIN_CPC,
        );

        expect(response.body.orientation).toBeDefined();
        expect(response.body.orientation).toBeTypeOf('string');

        expect(response.body.minBudget).toBeDefined();
        expect(response.body.minBudget).toBeTypeOf('number');
        expect(response.body.minBudget).greaterThan(0);

        expect(response.body.minDailyBudget).toBeDefined();
        expect(response.body.minDailyBudget).toBeTypeOf('number');
        expect(response.body.minDailyBudget).greaterThan(0);

        // expect(response.body.config).toBeDefined();
        // expect(
        //     typeof response.body.config === 'string' ||
        //         typeof response.body.config === 'object',
        // );

        // const config =
        //     typeof response.body.config === 'string'
        //         ? JSON.parse(response.body.config)
        //         : response.body.config;

        // expect(config).toHaveProperty('addons');

        const dbshelf = await connection('shelf')
            .where('id', response.body.id)
            .first();

        expect(dbshelf).toBeDefined();
        expect(dbshelf?.marketplaceId).eq(MARKETPLACES.TESTING);
    });
    it('when posting the marketplace should be replaced if not api', async () => {
        const response = await App.post('/shelf')
            .send({
                ...NewShelfObject,
                marketplaceId: MARKETPLACES.WECODE,
            })
            .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

        expect(response.status, 'the route should be defined').not.eq(404);
        expect(response.status).eq(200);

        expect(response.body.id, 'it has to have an id').toBeDefined();
        expect(response.body.id).toBeTypeOf('number');

        expect(response.body.name, 'it has to have an name').toBeDefined();
        expect(response.body.name).toBeTypeOf('string');

        expect(response.body.section).toBeDefined();
        expect(response.body.section).toBeTypeOf('number');
        expect(
            response.body.section ===
                CAMPAIGN_PLACEMENT.DEPARTMENT_CATEGORY ||
                response.body.section === CAMPAIGN_PLACEMENT.HOME ||
                response.body.section === CAMPAIGN_PLACEMENT.PRODUCT ||
                response.body.section === CAMPAIGN_PLACEMENT.SEARCH_RESULTS,
        ).toEqual(true);
        expect(response.body.status).toBeDefined();
        expect(response.body.status).toBeTypeOf('number');
        expect(Formatter.isValidStatus(response.body.status)).eq(true);

        expect(response.body.isActive).toBeDefined();
        if (typeof response.body.isActive === 'number') {
            expect(
                response.body.isActive === 1 || response.body.isActive === 0,
            ).toEqual(true);
        } else if (typeof response.body.isActive === 'boolean') {
            expect(response.body.isActive).toBeTypeOf('boolean');
        } else {
            expect(1).eq(0);
        }

        expect(response.body.marketplaceId).toBeDefined();
        expect(response.body.marketplaceId).toBeTypeOf('string');
        expect(response.body.marketplaceId).eq(MARKETPLACES.TESTING);

        expect(response.body.type).toBeDefined();
        expect(response.body.type).toBeTypeOf('number');
        expect(Formatter.isInEnum(response.body.type, CAMPAIGN_TYPES));

        expect(response.body.quantity).toBeDefined();
        expect(response.body.quantity).toBeTypeOf('number');
        expect(response.body.quantity).greaterThan(0);

        expect(response.body.minCpc).toBeDefined();
        expect(response.body.minCpc).toBeTypeOf('number');
        expect(response.body.minCpc).greaterThan(
            DEFAULTS.MARKETPLACE_PAYMENT.MIN_CPC,
        );

        expect(response.body.orientation).toBeDefined();
        expect(response.body.orientation).toBeTypeOf('string');

        expect(response.body.minBudget).toBeDefined();
        expect(response.body.minBudget).toBeTypeOf('number');
        expect(response.body.minBudget).greaterThan(0);

        expect(response.body.minDailyBudget).toBeDefined();
        expect(response.body.minDailyBudget).toBeTypeOf('number');
        expect(response.body.minDailyBudget).greaterThan(0);

        // expect(response.body.config).toBeDefined();
        // expect(
        //     typeof response.body.config === 'string' ||
        //         typeof response.body.config === 'object',
        // );

        // const config =
        //     typeof response.body.config === 'string'
        //         ? JSON.parse(response.body.config)
        //         : response.body.config;

        // expect(config).toHaveProperty('addons');

        const dbshelf = await connection('shelf')
            .where('id', response.body.id)
            .first();

        expect(dbshelf).toBeDefined();
        expect(dbshelf?.marketplaceId).not.eq(MARKETPLACES.WECODE);
    });

    it('when posting the marketplace should not be replaced if api', async () => {
        const response = await App.post('/shelf')
            .send({
                ...NewShelfObject,
                marketplaceId: MARKETPLACES.WECODE,
            })
            .set('Authorization', `Bearer ${API_ACCESS_TOKEN}`);

        expect(response.status, 'the route should be defined').not.eq(404);
        expect(response.status).eq(200);

        expect(response.body.id, 'it has to have an id').toBeDefined();
        expect(response.body.id).toBeTypeOf('number');

        expect(response.body.name, 'it has to have an name').toBeDefined();
        expect(response.body.name).toBeTypeOf('string');

        expect(response.body.section).toBeDefined();
        expect(response.body.section).toBeTypeOf('number');
        expect(
            response.body.section ===
                CAMPAIGN_PLACEMENT.DEPARTMENT_CATEGORY ||
                response.body.section === CAMPAIGN_PLACEMENT.HOME ||
                response.body.section === CAMPAIGN_PLACEMENT.PRODUCT ||
                response.body.section === CAMPAIGN_PLACEMENT.SEARCH_RESULTS,
        ).toEqual(true);
        expect(response.body.status).toBeDefined();
        expect(response.body.status).toBeTypeOf('number');
        expect(Formatter.isValidStatus(response.body.status)).eq(true);

        expect(response.body.isActive).toBeDefined();
        if (typeof response.body.isActive === 'number') {
            expect(
                response.body.isActive === 1 || response.body.isActive === 0,
            ).toEqual(true);
        } else if (typeof response.body.isActive === 'boolean') {
            expect(response.body.isActive).toBeTypeOf('boolean');
        } else {
            expect(1).eq(0);
        }

        expect(response.body.marketplaceId).toBeDefined();
        expect(response.body.marketplaceId).toBeTypeOf('string');
        expect(response.body.marketplaceId).eq(MARKETPLACES.WECODE);

        expect(response.body.type).toBeDefined();
        expect(response.body.type).toBeTypeOf('number');
        expect(Formatter.isInEnum(response.body.type, CAMPAIGN_TYPES));

        expect(response.body.quantity).toBeDefined();
        expect(response.body.quantity).toBeTypeOf('number');
        expect(response.body.quantity).greaterThan(0);

        expect(response.body.minCpc).toBeDefined();
        expect(response.body.minCpc).toBeTypeOf('number');
        expect(response.body.minCpc).greaterThan(
            DEFAULTS.MARKETPLACE_PAYMENT.MIN_CPC,
        );

        expect(response.body.orientation).toBeDefined();
        expect(response.body.orientation).toBeTypeOf('string');

        expect(response.body.minBudget).toBeDefined();
        expect(response.body.minBudget).toBeTypeOf('number');
        expect(response.body.minBudget).greaterThan(0);

        expect(response.body.minDailyBudget).toBeDefined();
        expect(response.body.minDailyBudget).toBeTypeOf('number');
        expect(response.body.minDailyBudget).greaterThan(0);

        // expect(response.body.config).toBeDefined();
        // expect(
        //     typeof response.body.config === 'string' ||
        //         typeof response.body.config === 'object',
        // );

        // const config =
        //     typeof response.body.config === 'string'
        //         ? JSON.parse(response.body.config)
        //         : response.body.config;

        // expect(config).toHaveProperty('addons');

        const dbshelf = await connection('shelf')
            .where('id', response.body.id)
            .first();

        expect(dbshelf).toBeDefined();
        expect(dbshelf?.marketplaceId).eq(MARKETPLACES.WECODE);
    });
});

describe('post', () => {
    it('should be able to post', async () => {
        const response = await App.post('/shelf')
            .send(NewShelfObject)
            .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

        expect(response.status).not.eq(404);
        expect(response.status).eq(200);
    });

    it.skip('should not be able to post  the marketplaceId', async () => {
        const response = await App.post('/shelf')
            .send({
                ...NewShelfObject,
                marketplaceId: 'some random marketplaceId',
            })
            .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

        expect(response.status).not.eq(404);
        expect(response.status).not.eq(200);
    });
    it('should not be able to post with wrong type ', async () => {
        const response = await App.post(`/shelf`)
            .send({
                name: 3,
                section: {},
                status: '333',
                isActive: '34',
                marketplaceId: [],
                type: '1',
                quantity: '9032',
                minCpc: '3',
                orientation: {},
                minBudget: '3',
                minDailyBudget: '30932',
                // config: 3,
            })
            .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

        expect(response.status).not.eq(404);
        expect(response.status).not.eq(200);
    });
    // it('should not be able to post with wrong config', async () => {
    //     const response = await App.post(`/shelf`)
    //         .send({
    //             name: '',
    //             section: CAMPAIGN_PLACEMENT.DEPARTMENT_CATEGORY,
    //             status: ItemStatus.ACTIVE,
    //             isActive: true,
    //             marketplaceId: '',
    //             type: CAMPAIGN_TYPES.SPONSORED_PRODUCTS,
    //             quantity: 3,
    //             minCpc: 3,
    //             orientation: 'horizontal',
    //             minBudget: 0,
    //             minDailyBudget: 0,
    //             config: {
    //                 items: ['add'],
    //             },
    //         })
    //         .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

    //     expect(response.status).not.eq(404);
    //     expect(response.status).not.eq(200);
    // });

    it('should not be able to post with neg values', async () => {
        const response = await App.post(`/shelf`)
            .send({
                name: '',
                section: CAMPAIGN_PLACEMENT.DEPARTMENT_CATEGORY,
                status: ItemStatus.ACTIVE,
                isActive: true,
                marketplaceId: '',
                type: CAMPAIGN_TYPES.SPONSORED_PRODUCTS,
                quantity: -1,
                minCpc: -1,
                orientation: 'horizontal',
                minBudget: -1,
                minDailyBudget: -1,
                // config: {
                //     items: ['add'],
                // },
            })
            .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

        expect(response.status).not.eq(404);
        expect(response.status).not.eq(200);
    });

    // it('should not be able to update with invalid config', async () => {
    //     const shelfResponse = await App.post('/shelf/')
    //         .send(NewShelfObject)
    //         .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

    //     const response = await App.put(`/shelf/${shelfResponse.body.id}`)
    //         .send({
    //             name: '',
    //             section: CAMPAIGN_PLACEMENT.DEPARTMENT_CATEGORY,
    //             status: ItemStatus.ACTIVE,
    //             isActive: true,
    //             marketplaceId: '',
    //             type: CAMPAIGN_TYPES.SPONSORED_PRODUCTS,
    //             quantity: 0,
    //             minCpc: 0,
    //             orientation: 'horizontal',
    //             minBudget: 0,
    //             minDailyBudget: 0,
    //             config: {
    //                 items: ['add'],
    //             },
    //         })
    //         .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

    //     expect(response.status).not.eq(404);
    //     expect(response.status).not.eq(200);
    // });
});
describe('updating', () => {
    it('should be able to update', async () => {
        const response = await App.post('/shelf')
            .send(NewShelfObject)
            .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

        const updateResponse = await App.put(`/shelf/${response.body.id}`)
            .send({
                ...NewShelfObject,
                name: 'new name',
            })
            .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

        expect(updateResponse.status).not.eq(404);
        expect(updateResponse.status).eq(200);
    });

    it('should not be able to update the marketplaceId', async () => {
        const response = await App.post('/shelf')
            .send(NewShelfObject)
            .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

        const previousMarketplaceId = response.body.marketplaceId;

        const updateResponse = await App.put(`/shelf/${response.body.id}`)
            .send({
                ...NewShelfObject,
                marketplaceId: 'some random marketplaceId',
                name: 'new name',
            })
            .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

        expect(updateResponse.status).not.eq(404);
        expect(updateResponse.status).eq(200);
        expect(updateResponse.body.marketplaceId).eq(previousMarketplaceId);
    });
    it('should not be able to update with wrong type ', async () => {
        const response = await App.post('/shelf')
            .send(NewShelfObject)
            .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

        const updateResponse = await App.put(`/shelf/${response.body.id}`)
            .send({
                name: 3,
                section: {},
                status: '333',
                isActive: '34',
                marketplaceId: [],
                type: '1',
                quantity: '9032',
                minCpc: '3',
                orientation: {},
                minBudget: '3',
                minDailyBudget: '30932',
                // config: 3,
            })
            .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

        expect(updateResponse.status).not.eq(404);
        expect(updateResponse.status).not.eq(200);
    });
    // it('should not be able to update with wrong config', async () => {
    //     const response = await App.post('/shelf')
    //         .send(NewShelfObject)
    //         .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

    //     const updateResponse = await App.put(`/shelf/${response.body.id}`)
    //         .send({
    //             name: '',
    //             section: CAMPAIGN_PLACEMENT.DEPARTMENT_CATEGORY,
    //             status: ItemStatus.ACTIVE,
    //             isActive: true,
    //             marketplaceId: '',
    //             type: CAMPAIGN_TYPES.SPONSORED_PRODUCTS,
    //             quantity: 3,
    //             minCpc: 3,
    //             orientation: 'horizontal',
    //             minBudget: 0,
    //             minDailyBudget: 0,
    //             config: {
    //                 items: ['add'],
    //             },
    //         })
    //         .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

    //     expect(updateResponse.status).not.eq(404);
    //     expect(updateResponse.status).not.eq(200);
    // });

    it('should not be able to update with neg values', async () => {
        const response = await App.post('/shelf')
            .send(NewShelfObject)
            .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

        const updateResponse = await App.put(`/shelf/${response.body.id}`)
            .send({
                name: '',
                section: CAMPAIGN_PLACEMENT.DEPARTMENT_CATEGORY,
                status: ItemStatus.ACTIVE,
                isActive: true,
                marketplaceId: '',
                type: CAMPAIGN_TYPES.SPONSORED_PRODUCTS,
                quantity: -1,
                minCpc: -1,
                orientation: 'horizontal',
                minBudget: -1,
                minDailyBudget: -1,
                // config: {
                //     items: ['add'],
                // },
            })
            .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

        expect(updateResponse.status).not.eq(404);
        expect(updateResponse.status).not.eq(200);
    });

    // it('should not be able to update with invalid config', async () => {
    //     const response = await App.post('/shelf')
    //         .send(NewShelfObject)
    //         .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

    //     const updateResponse = await App.put(`/shelf/${response.body.id}`)
    //         .send({
    //             name: '',
    //             section: CAMPAIGN_PLACEMENT.DEPARTMENT_CATEGORY,
    //             status: ItemStatus.ACTIVE,
    //             isActive: true,
    //             marketplaceId: '',
    //             type: CAMPAIGN_TYPES.SPONSORED_PRODUCTS,
    //             quantity: 0,
    //             minCpc: 0,
    //             orientation: 'horizontal',
    //             minBudget: 0,
    //             minDailyBudget: 0,
    //             config: {
    //                 items: ['add'],
    //             },
    //         })
    //         .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

    //     expect(updateResponse.status).not.eq(404);
    //     expect(updateResponse.status).not.eq(200);
    // });
});

describe('deletion', () => {
    it('can delete normally', async () => {
        const response = await App.post('/shelf')
            .send(NewShelfObject)
            .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

        expect(response.status).not.eq(404);
        expect(response.status).eq(200);

        const deleteResponse = await App.delete(
            `/shelf/${response.body.id}`,
        ).set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

        expect(deleteResponse.status).eq(200);
        expect(deleteResponse.body).eq(true);

        const shelf = await connection('shelf')
            .where('id', response.body.id)
            .first();

        expect(shelf).toBeDefined();
        expect(shelf?.status).eq(ItemStatus.DELETED);

        const getResp = await App.get(`/shelf/${response.body.id}`).set(
            'Authorization',
            `Bearer ${TESTING_ACCESS_TOKEN}`,
        );

        expect(getResp.status).not.eq(200);
        expect(getResp.status).not.eq(404);
    });

    it('cannot delete when is already deleted', async () => {
        const response = await App.post('/shelf')
            .send(NewShelfObject)
            .set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

        expect(response.status).not.eq(404);
        expect(response.status).eq(200);

        const deleteResponse = await App.delete(
            `/shelf/${response.body.id}`,
        ).set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`);

        expect(deleteResponse.status).eq(200);
        expect(deleteResponse.body).eq(true);

        const shelf = await connection('shelf')
            .where('id', response.body.id)
            .first();

        expect(shelf).toBeDefined();
        expect(shelf?.status).eq(ItemStatus.DELETED);

        const getResp = await App.get(`/shelf/${response.body.id}`).set(
            'Authorization',
            `Bearer ${TESTING_ACCESS_TOKEN}`,
        );

        expect(getResp.status).not.eq(200);
        expect(getResp.status).not.eq(404);

        const otherDel = await App.delete(`/shelf/${response.body.id}`).set(
            'Authorization',
            `Bearer ${TESTING_ACCESS_TOKEN}`,
        );

        expect(otherDel.status).not.eq(404);
        expect(otherDel.status).not.eq(200);
    });
});
