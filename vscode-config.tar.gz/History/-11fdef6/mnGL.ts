import { Response } from 'supertest'
import { App } from '__tests__/vitest.setup'
import { TESTING_ACCESS_TOKEN  } from 'src/constants'
import { HTTPCodes } from 'src/lib/ErrorHandling/ErrorHandler'
import { describe, it, expect, beforeAll } from 'vitest'
import { CampaignInfo } from 'wecubedigital'

let campaign: CampaignInfo
let response: Response
let campaignResponse: Response

beforeAll(async () => {
    response = await App?.get('/campaigns')
    .set('Authorization', TESTING_ACCESS_TOKEN)
    campaign = response.body[0]

    campaignResponse = await App?.get(`/campaigns/${campaign.id}`)
    .set('Authorization', TESTING_ACCESS_TOKEN)
})

describe('Teste de rotas de campanhas', () => {
    it('GET - All', () => {
        expect(response.body.length).greaterThan(0)
        expect(response.status).toEqual(HTTPCodes.OK)
    })
    it('GET - One', () => {
        expect(campaignResponse.body).toBeTypeOf('object')
        expect(campaignResponse.status).toEqual(HTTPCodes.OK)
    })
    it('POST - campaign', async () => {
        const response = await App.post('/campaigns/')
        .set('Authorization', TESTING_ACCESS_TOKEN)
        .send(campaign)
        console.log(campaign)
        expect(response.body).toBeTypeOf('object')
        expect(response.status).toEqual(HTTPCodes.OK)
    })
    it('UPDATE - campaign', async () => {
        const response = await App.put(`/campaigns/${campaign.id}`)
        .set('Authorization', TESTING_ACCESS_TOKEN)
        .send(campaign)

        expect(response.body).toBeTypeOf('object')
        expect(response.status).toEqual(HTTPCodes.OK)
    })
    it('DELETE - campaign', async () => {
        const response = await App.delete(`/campaigns/${campaign.id}`)
        .set('Authorization', TESTING_ACCESS_TOKEN)

        expect(response.body).toBeTypeOf('boolean')
        expect(response.body).toEqual(true)
        expect(response.status).toEqual(HTTPCodes.OK)
    })
})
