import type { Knex } from "knex";

export function up(knex: Knex): Promise<void> {
     return knex.schema.table('banner_ads', function(table) {
          table.json('metadata')
     })
}

export function down(knex: Knex): Promise<void> {
     return knex.schema.table('banner_ads', function(table) {
          table.dropColumn('metadata')
     })
}

