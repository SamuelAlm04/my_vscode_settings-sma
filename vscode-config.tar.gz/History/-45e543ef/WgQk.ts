import type { Knex } from 'knex';
import { InteractionHistory, ItemStatus, ItemTableFields, MarketplaceInfo, SellerFunds, TableFields, TableNames } from 'wecubedigital';
import { connection } from 'src/db';
import { InteractionHistory, ItemStatus, ItemTableFields, MarketplaceInfo, SellerFunds, TableFields, TableNames } from 'wecubedigital';
export type Status<T extends TableNames = TableNames> = {
    table: T;
    descriminator: keyof ItemTableFields[T];
    descriminatorValue: string;
    status: ItemStatus;
};
type N = TableFields & {
    interaction_history: InteractionHistory;
    status: Status;
    seller_funds: SellerFunds;
    marketplaces: MarketplaceInfo;
};
declare module 'knex/types/tables' {
    interface Tables extends N {
    }
}
export declare const config: {
    [key: string]: Knex.Config;
};
export default config;
export declare function tableIndexExist(knex: typeof connection, tableName: string, indName: string): Promise<boolean>;
