import { NextFunction, Request, Response, Router } from 'express';
import { ParamsDictionary } from 'express-serve-static-core';
import {
    CategorySpecification,
    CategorySpecificationObject,
    ItemStatus,
    NewCategorySpecification,
    NewCategorySpecificationObject,
} from 'wecubedigital';
import { logging } from '../../Logging/Log';

import { Tspec } from 'tspec';
import { Managers } from '../../Managers/Managers';
import {
    InternalError,
    InvalidItemError,
    NotFoundError,
} from '../../lib/ErrorHandling/ErrorHandler';
import { Formatter } from '../../lib/Formatter';
import {
    ApiDeleteStatus,
    ApiGetStatus,
    ApiPostStatus,
    ApiUpdateStatus,
    QueryFilter,
} from '../../types/backendTypes';
import { ContextFactory } from '../../lib/context/DatabaseContext';
import { DatabaseQuery } from '../../types/storageType';
import { ContextBuilder } from '../../lib/context/ContextBuilder';
import { ValidationCluster } from '../../lib/Validation/ItemValidation/ItemValidationCluster';
import { BoundsValidator } from '../../lib/Validation/ItemValidation/BoundsValidator';
import {
    ERROR_CODES,
    ItemPropertyValidator,
} from '../../lib/Validation/ItemValidation/itemValidation';
import { Validation } from '../../lib/Validation/Validation';
import { BOUND_EDGES } from 'src/constants';

export const categorySpecificationRouter: Router = Router({
    mergeParams: true,
});

type CategorySpecificationRequest = Request<
    { categoryId: string },
    unknown,
    unknown,
    QueryFilter<CategorySpecification>
>;
type NewSpecificationRequest = Request<
    ParamsDictionary,
    unknown,
    NewCategorySpecification
>;
type UpdateSpecificationRequest = Request<
    ParamsDictionary,
    unknown,
    NewCategorySpecification
>;
type SpecificationResponse = Response<CategorySpecification>;

export class CategorySpecificationController {
    static async GetSpecifications(
        req: CategorySpecificationRequest,
        res: Response,
        next: NextFunction,
    ) {
        const categorySpecificationManager = Managers.get(
            'category_specification',
        );

        const categoryId = req.category!.id!;

        const specification =
            await categorySpecificationManager.getSpecificationsByParentId(
                categoryId,
                ContextFactory.fromRequest(
                    'category_specification',
                    categorySpecificationManager.Context() as DatabaseQuery<'category_specification'>,
                    req,
                )
                    .SetParameters(
                        ContextBuilder.FromParameters(
                            req.query,
                            CategorySpecificationObject,
                        ),
                    )
                    .Build(),
            );

        if (!specification)
            return next(new NotFoundError('Category Specification Not Found'));

        res.json(specification);
    }
    static async SpecificationIdMiddleware(
        req: CategorySpecificationRequest,
        _: Response,
        next: NextFunction,
        specificationId: string,
    ) {
        const categorySpecificationmanager = Managers.get(
            'category_specification',
        );

        const specification = await categorySpecificationmanager.getById(
            Number(specificationId),
            categorySpecificationmanager.Context(),
        );

        if (!specification || specification.categoryId !== req.category?.id)
            return next(new NotFoundError('Specification Not Found'));

        req.category_specification = specification;
        next();
    }
    static getSpecification(
        req: CategorySpecificationRequest,
        res: SpecificationResponse,
    ) {
        return res.json(req.category_specification);
    }
    static async updateSpecification(
        req: UpdateSpecificationRequest,
        res: SpecificationResponse,
    ) {
        const specificationId = req.category_specification!.id!;
        const categorySpecificationManager = Managers.get(
            'category_specification',
        );

        const cleanedSpecification =
            Formatter.cleanObject<NewCategorySpecification>(
                req.body,
                NewCategorySpecificationObject,
            );

        cleanedSpecification.categoryId = req.category!.id;

        const categoryValidator =
            new ValidationCluster<NewCategorySpecification>()
                .add(
                    new BoundsValidator<NewCategorySpecification>(
                        NewCategorySpecificationObject,
                        BOUND_EDGES,
                    ),
                )
                .add(
                    new ItemPropertyValidator<NewCategorySpecification>().add(
                        (item) =>
                            item.status && Formatter.isValidStatus(item.status),
                        (item) =>
                            Validation.messages.invalid(
                                `${Formatter.getEnumKeyByValue(ItemStatus, item.status)}`,
                                'status',
                                ERROR_CODES.INVALID_VALUE,
                            ),
                    ),
                );
        const hasErrors = categorySpecificationManager.hasErrors(
            cleanedSpecification,
            NewCategorySpecificationObject,
            categoryValidator,
        );

        if (hasErrors) {
            throw new InvalidItemError(hasErrors.getErrors());
        }

        const data = await categorySpecificationManager.update(
            specificationId,
            cleanedSpecification,
        );

        if (!data) throw new InternalError('Could not Update');

        logging.add('category_specification:put', {
            id: data.id,
            creator: req.user!.info.id,
        });

        res.json(data);
    }
    static async deleteSpecification(
        req: CategorySpecificationRequest,
        res: Response<boolean>,
    ) {
        const specificationId = req.category_specification!.id!;

        const categorySpecificationManager = Managers.get(
            'category_specification',
        );

        const specification = await categorySpecificationManager.getById(
            specificationId,
            categorySpecificationManager.Context(),
        );

        if (!specification) throw new NotFoundError('invalid Specification');

        const data = await categorySpecificationManager.hide(specificationId);

        if (!data) throw new InternalError('Could not Delete Specification');

        logging.add('category_specification:delete', {
            id: specificationId,
            creator: req.user!.info.id,
        });

        res.json(data);
    }
    static async NewSpecification(
        req: NewSpecificationRequest,
        res: SpecificationResponse,
    ) {
        const categorySpecificationManager = Managers.get(
            'category_specification',
        );
        const cleanedSpecification =
            Formatter.cleanObject<NewCategorySpecification>(
                req.body,
                NewCategorySpecificationObject,
            );

        cleanedSpecification.categoryId = req.category!.id;

        const categorySpecificationValidator =
            new ValidationCluster<NewCategorySpecification>().add(
                new BoundsValidator(NewCategorySpecificationObject, BOUND_EDGES),
            );

        const hasErrors = categorySpecificationManager.hasErrors(
            cleanedSpecification,
            NewCategorySpecificationObject,
            categorySpecificationValidator,
        );

        if (hasErrors) {
            throw new InvalidItemError(hasErrors.getErrors());
        }

        if (!categorySpecificationValidator.isValid(cleanedSpecification)) {
            throw new InvalidItemError(
                categorySpecificationValidator.getErrors(),
            );
        }

        const data =
            await categorySpecificationManager.upload(cleanedSpecification);

        if (!data) throw new InternalError('Could not Upload');

        logging.add('category_specification:post', {
            id: data.id,
            creator: req.user!.info.id,
        });

        res.json(data);
    }
}

export type CategorySpecificationDefs2 = Tspec.DefineApiSpec<{
    tags: ['Category', 'Category Specification'];
    security: 'jwt';
    basePath: '/categories/{categoryId}/specification';
    paths: {
        '/': {
            get: {
                responses: ApiGetStatus<{ 200: CategorySpecification[] }>;
                summary: 'Get Specifications';
                query: QueryFilter<CategorySpecification>;
                handler: typeof CategorySpecificationController.GetSpecifications;
            };
            post: {
                responses: ApiPostStatus<{ 200: CategorySpecification }>;
                summary: 'New Specification';
                handler: typeof CategorySpecificationController.NewSpecification;
            };
        };
        '/{specificationId}': {
            get: {
                summary: 'Get Specification';
                responses: ApiGetStatus<{ 200: CategorySpecification }>;
                handler: typeof CategorySpecificationController.getSpecification;
            };
            put: {
                summary: 'Update Specification';
                responses: ApiUpdateStatus<{ 200: CategorySpecification }>;
                handler: typeof CategorySpecificationController.updateSpecification;
            };
            delete: {
                summary: 'Delete Specification';
                responses: ApiDeleteStatus<{ 200: boolean }>;
                handler: typeof CategorySpecificationController.deleteSpecification;
            };
        };
    };
}>;

// categorySpecificationRouter.use(
//     '/',
//     (req, res, next) =>
//         permissionsHandler.validateRoute(
//             RolePermission.CATEGORY_SPECIFICATION,
//             req,
//             res,
//             next
//         ),
// );

categorySpecificationRouter.get(
    '/',
    CategorySpecificationController.GetSpecifications,
);
categorySpecificationRouter.param(
    'specificationId',
    //@ts-expect-error always needs to be with category behind it
    CategorySpecificationController.SpecificationIdMiddleware,
);

categorySpecificationRouter.get(
    '/:specificationId',
    CategorySpecificationController.getSpecification,
);

categorySpecificationRouter.put(
    '/:specificationId',
    CategorySpecificationController.updateSpecification,
);

categorySpecificationRouter.delete(
    '/:specificationId',
    CategorySpecificationController.deleteSpecification,
);

categorySpecificationRouter.post(
    '/',
    CategorySpecificationController.NewSpecification,
);
