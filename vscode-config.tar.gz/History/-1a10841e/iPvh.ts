import { Response } from 'supertest'
import { App } from '__tests__/vitest.setup'
import { TESTING_ACCESS_TOKEN } from 'src/constants'
import { HTTPCodes } from 'src/lib/ErrorHandling/ErrorHandler'
import { describe, it, expect, beforeAll } from 'vitest'
import { SkuPriceInfo, SkuInfo } from 'wecubedigital'

let sku: SkuInfo
let skuPrice: SkuPriceInfo
let response: Response
let skuResponse: Response

beforeAll(async () => {
    response = await App!.get('/sku')
    .set('Authorization', TESTING_ACCESS_TOKEN)

    sku = response.body[0]
    expect(response.body.length).toBeGreaterThan(0)
    expect(response.status).toEqual(HTTPCodes.OK)

    skuResponse = await App!.get(`/sku/${sku.id}/prices`)
    .set('Authorization', TESTING_ACCESS_TOKEN)

    skuPrice = skuResponse.body[0]
    expect(skuResponse.body.length).toBeGreaterThan(0)
    expect(skuResponse.status).toEqual(HTTPCodes.OK)
})

describe('Teste de rotas SKU price', () => {
    it('GET - One', async () => {
        const response = await App!.get(`/sku/${sku.id}/prices/${skuPrice.id}`)
        .set('Authorization', TESTING_ACCESS_TOKEN)

        expect(response.body).toBeTypeOf('object')
        expect(response.status).toEqual(HTTPCodes.OK)
    })
    it('POST - SKU price', async () => {
        response = await App!.post(`/sku/${sku.id}/prices`)
        .set('Authorization', TESTING_ACCESS_TOKEN)
        .send(skuPrice)

        expect(response.body).toBeTypeOf('object')
        expect(response.status).toEqual(HTTPCodes.OK)
    })
    it('UPDATE - SKU price', async () => {
        response = await App!.put(`/sku/${sku.id}/prices/${skuPrice.id}`)
        .set('Authorization', TESTING_ACCESS_TOKEN)
        .send(skuPrice)

        expect(response.body).toBeTypeOf('object')
        expect(response.status).toEqual(HTTPCodes.OK)
    })
    it('DELETE - SKU price', async () => {
        response = await App!.delete(`/sku/${sku.id}/prices/${skuPrice.id}`)
        .set('Authorization', TESTING_ACCESS_TOKEN)

        expect(response.body).toBeTypeOf('boolean')
        expect(response.body).toEqual(true)
        expect(response.status).toEqual(HTTPCodes.OK)
    })
})
