import { App } from '__tests__/vitest.setup';
import { MIN_VALUES, TESTING_ACCESS_TOKEN } from 'src/constants';
import { connection } from 'src/db';
import { HTTPCodes } from 'src/lib/ErrorHandling/ErrorHandler';
import { Managers } from 'src/Managers/Managers';
import { describe, expect, it } from 'vitest';
import {
    CAMPAIGN_TYPES,
    ItemStatus,
    MARKETPLACES,
    SELLERS,
} from 'wecubedigital';
import { z } from 'zod';

//const baseCampaign = {
//     campaignId: 581,
//     id: 1109,
//     status: 4,
//     isActive: true,
//     sold: 0,
//     views: 0,
//     clicks: 0,
//     ctr: 0,
//     cr: 0,
//     cpc: 31,
//     type: BannerAdObject.type,
//     image_url: BannerAdObject.image_url,
//     redirect_url: BannerAdObject.redirect_url,
//     approvalStatus: BannerAdObject.approvalStatus,
//     metadata: BannerAdObject.metadata,
//};

const campaignRequestSchema = z.object({
    campaignId: z.number(),
    id: z.number(),
    status: z.number(),
    isActive: z.boolean(),
    sold: z.number(),
    views: z.number(),
    clicks: z.number(),
    ctr: z.number(),
    cr: z.number(),
    cpc: z.number().gt(MIN_VALUES.CPC),
    image_url: z.string(),
    type: z.string(),
    redirect_url: z.string(),
    approvalStatus: z.number(),
    metadata: z.string().or(
        z.object({
            categories: z.number().array(),
        })
    ),
});
describe('Campaign new request test', () => {
    it('GET - New Request', async () => {
        const campaignID = await connection('campaigns')
            .select('id')
            .where('status', ItemStatus.ACTIVE)
            .andWhere('marketplaceId', MARKETPLACES.TESTING)
            .andWhere('type', CAMPAIGN_TYPES.BANNER_AND_VIDEO)
            .andWhere('sellerId', SELLERS.CUBE)
            .first();

        const response = await App!
            .get(
                `/api/dashboard/seller/campaign/${campaignID?.id}?date=2021-01-01,2027-06-06&limit=10&offset=0`
            )
            .set('Authorization', TESTING_ACCESS_TOKEN);

        expect(response.status).eq(200);

        const [orders, ints] = await Promise.all([
            connection('orders')
                .select('adId')
                .count('adId as count')
                .where('status', ItemStatus.ACTIVE)
                .whereIn(
                    'adId',
                    response.body.data.map((item: { id: number }) => item.id)
                )
                .groupBy('adId') as Promise<
                {
                    count: number | string;
                    adId: number;
                }[]
            >,
            Managers.get('interactions').buildInteractions(
                response.body.data.map((item: { id: number }) => item.id),
                connection
            ) as unknown as Promise<
                {
                    clicks: number;
                    views: number;
                    adId: number;
                }[]
            >,
        ]);

        expect(response.body).toBeTypeOf('object');
        expect(response.body.data).toBeTypeOf('object');
        expect(Array.isArray(response.body.data)).toBe(true);
        expect(response.body.data.length).lessThanOrEqual(
            response.body.info.total
        );
        expect(response.status).toEqual(HTTPCodes.OK);
        for (const ad of response.body.data) {
            const validSchema = campaignRequestSchema.safeParse(ad);

            if (validSchema.success === false) {
                logger.error('invalid item', validSchema.error.issues);
            }
            expect(validSchema.success).toEqual(true);

            const order = orders.find((o) => o.adId === ad.id);

            expect(order).toBeDefined();
            assert.ok(order);

            expect(order.count).toEqual(ad.sold);

            const int = ints.find((i) => i.adId === ad.id);
            assert.ok(int);

            expect(ad.views).toEqual(int.views);
            expect(ad.clicks).toEqual(int.clicks);

            const ctr = ad.clicks / ad.views;
            const cr = ad.sold / ad.views;

            expect(ctr).toEqual(ad.ctr);
            expect(cr).toEqual(ad.cr);
        }
    });
});
