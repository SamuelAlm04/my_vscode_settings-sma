import { App } from '__tests__/vitest.setup';
import { TESTING_ACCESS_TOKEN } from 'src/constants';
import { describe, it, expect } from 'vitest'
describe('teste de rotas de produtos', () => {
    it('get', async () => {
        // expect(1 + 1 ).equals(2)
        const response = await App?.get('/products')
        .set('Authorization', TESTING_ACCESS_TOKEN)!

        expect(response.status)



    })
})