import { Response } from 'supertest';
import { App } from '__tests__/vitest.setup';
import { TESTING_ACCESS_TOKEN } from 'src/constants';
import { HTTPCodes } from 'src/lib/ErrorHandling/ErrorHandler';
import { describe, it, expect, beforeAll } from 'vitest'
import { ProductInfo } from 'wecubedigital';

let product: ProductInfo
let response : Response
beforeAll(async () => {

    response = await App?.get('/products')
    .set('Authorization', TESTING_ACCESS_TOKEN)

    product = response.body[0]


})



describe('teste de rotas de produtos', () => {
    it ("response ok", () => {
        expect(response.status).toEqual(HTTPCodes.OK)
    })
    it('get',  () => {
        // expect(1 + 1 ).equals(2)
    
        
        
        expect(response.body.length).greaterThan(0)



    })
})