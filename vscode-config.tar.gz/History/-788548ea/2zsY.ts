import { describe, it, expect } from 'vitest'
describe('teste de rotas de produtos', () => {
    it('get', () => {
        expect(1 + 1 ).equals(2)
    })
})