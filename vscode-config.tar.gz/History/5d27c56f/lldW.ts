import { ConversionNodeKeys, ConversionTableItem, ConversionTableObject, MARKETPLACES, TableFields, TableNames } from 'wecubedigital';
import { Table } from '../../types/storageType';
export declare const BASE_CONVERSION_CONFIG: {
    readonly key: "id";
    readonly previousKey: "previousId";
    readonly marketplaceId: MARKETPLACES.WECODE;
    readonly marketplaceKey: "marketplaceId";
};
/**
 *
 * This handles all the conversion, it gets the conversion table from the database and syncs it with method sync , accepting a storage instance, then it converts the items with the method convertItem
 *
 */
export declare class ConversionInstance<K extends ConversionNames, Input extends string | number = number, Output extends string | number = Input> {
    /**
     * The name of the table, it must be the same as the database table
     */
    readonly name: ConversionNames;
    private readonly key;
    private readonly previousKey;
    table: ConversionTable<Input, Output>;
    private readonly marketplace;
    private readonly marketplaceKey;
    private mode;
    private defaultIds?;
    constructor(name: K, props: {
        key: keyof TableFields[K];
        previousKey: keyof TableFields[K];
        marketplace: MARKETPLACES;
        marketplaceKey: keyof TableFields[K];
    });
    setMode(mode: 'current' | 'previous'): this;
    get filename(): string;
    setIds<T extends 'current' | 'previous'>(ids: T extends 'current' ? Output[] : Input[], mode?: 'current' | 'previous'): this;
    get filepath(): string;
    setup(): Promise<this>;
    convert(value: Output): Input | undefined;
    addNode(node: ConversionTableItem<Input, Output>): void;
    sync<TableName extends TableNames>(storage: Table<TableName>): Promise<void>;
    save(): Promise<void>;
}
export declare class ConversionTable<Input, Output = Input> {
    private _items;
    private currentItems;
    private previousItems;
    constructor(props?: {
        initialItems: ConversionTableItem<Input, Output>[];
    });
    get items(): ConversionTableItem<Input, Output>[];
    convert(item: Output): Input | undefined;
    add(node: ConversionTableItem<Input, Output>): this;
    remove(node: ConversionTableItem<Input, Output>): this;
    get<T extends ConversionNodeKeys>(type: ConversionNodeKeys, id: T extends 'current' ? Input : Output): ConversionTableItem<Input, Output> | undefined;
    exists<T extends ConversionNodeKeys>(type: T, id: T extends 'current' ? Input : Output): boolean;
    getOutliers(type: ConversionNodeKeys, items: Input[]): Input[];
}
export type ConversionTypes = typeof BaseConversionInstanceItems;
export declare class ConversionCluster {
    private instances;
    constructor();
    get<T extends ConversionNames>(key: T): ConversionTypes[T];
    add<K extends ConversionNames>(table: ConversionInstance<K, string | number>): this;
    setup(): Promise<(ConversionInstance<"sellers", number, string> | ConversionInstance<"brands", string | number, string | number> | ConversionInstance<"categories", string | number, string | number> | ConversionInstance<"attachments", string | number, string | number> | ConversionInstance<"brand_context", string | number, string | number> | ConversionInstance<"category_specification", string | number, string | number> | ConversionInstance<"sku_price", string | number, string | number> | ConversionInstance<"vtex_products", string | number, string | number> | ConversionInstance<"products_specification", string | number, string | number> | ConversionInstance<"vtex_sku", string | number, string | number> | ConversionInstance<"vtex_sku_attachment", string | number, string | number> | ConversionInstance<"vtex_sku_file", string | number, string | number> | ConversionInstance<"sku_inventory", string | number, string | number> | ConversionInstance<"sku_specification", string | number, string | number> | ConversionInstance<"sku", string | number, string | number> | ConversionInstance<"sku_kit", string | number, string | number>)[]>;
    sync(): Promise<void[]>;
    convertItem<T extends ConversionNames>(key: T, item: TableFields[T]): {
        products: {
            releaseDate: string;
            id: number;
            sellerId: number;
            previousSellerId: string;
            name: string;
            departmentId: number;
            categoryId: number;
            previousCategoryId: number;
            isActive: boolean;
            brandId: number;
            previousBrandId: number;
            linkId: string;
            refId: string;
            isVisible: number;
            description: string;
            descriptionShort: string;
            keyWords: string;
            marketplaceId: MARKETPLACES;
            title: string;
            taxCode: string;
            metaTagDescription: string;
            supplierId: string;
            showWithoutStock: number;
            adWordsRemarketingCode: string;
            lomadeeCampaignCode: string;
            status: import("wecubedigital").ItemStatus;
            previousId: number;
        };
        sku: {
            sellerId: import("wecubedigital").SELLERS;
            previousSellerId: string;
            previousId: number;
            previousProductId: number;
            marketplaceId: MARKETPLACES;
            status: import("wecubedigital").ItemStatus;
            productId: number;
            activateIfPossible: boolean;
            name: string;
            isPersisted: boolean;
            refId: string;
            packagedHeight: number;
            packagedLength: number;
            packagedWidth: number;
            packagedWeightKg: number;
            height: number;
            length: number;
            width: number;
            weightKg: number;
            cubicWeight: number;
            isKit: boolean;
            creationDate: string;
            rewardValue: string;
            manufacturerCode: string;
            commercialConditionId: number;
            measurementUnit: string;
            unitMultiplier: number;
            isActive: boolean;
            modalType: string;
            kitItensSellApart: boolean;
            videos: string | string[];
            id: number;
        };
        vtex_sku: {
            id: number;
            previousId: number;
            previousProductId: number;
            marketplaceId: MARKETPLACES;
            status: import("wecubedigital").ItemStatus;
            productId: number;
            activateIfPossible: boolean;
            name: string;
            isPersisted: boolean;
            refId: string;
            packagedHeight: number;
            packagedLength: number;
            packagedWidth: number;
            packagedWeightKg: number;
            height: number;
            length: number;
            width: number;
            weightKg: number;
            cubicWeight: number;
            isKit: boolean;
            creationDate: string;
            rewardValue: string;
            manufacturerCode: string;
            commercialConditionId: number;
            measurementUnit: string;
            unitMultiplier: number;
            isActive: boolean;
            modalType: string;
            kitItensSellApart: boolean;
            videos: string | string[];
        };
        vtex_sku_file: {
            id: number;
            archiveId: number;
            previousId: number;
            marketplaceId: MARKETPLACES;
            name: string;
            previousSkuId: number;
            skuId: number;
            isMain: number;
            url: string;
            label: string;
        };
        marketplaces: {
            id: string;
            name: string;
            platformId: import("wecubedigital").PLATFORMS;
            accountId: string;
            status: import("wecubedigital").ItemStatus;
        };
        marketplace_payment: {
            id: string;
            minCpc: number;
            applicationFee: number;
        };
        domains: {
            url: string;
            status: import("wecubedigital").ItemStatus;
            isMain: boolean;
            isActive: boolean;
            marketplaceId: MARKETPLACES;
            id: number;
        };
        vtex_products: {
            releaseDate: string;
            id: number;
            name: string;
            departmentId: number;
            categoryId: number;
            previousCategoryId: number;
            isActive: boolean;
            brandId: number;
            previousBrandId: number;
            linkId: string;
            refId: string;
            isVisible: number;
            description: string;
            descriptionShort: string;
            keyWords: string;
            marketplaceId: MARKETPLACES;
            title: string;
            taxCode: string;
            metaTagDescription: string;
            supplierId: string;
            showWithoutStock: number;
            adWordsRemarketingCode: string;
            lomadeeCampaignCode: string;
            status: import("wecubedigital").ItemStatus;
            previousId: number;
        };
        vtex_sku_price: {
            id: number;
            skuId: number;
            listPrice: number;
            marketplaceId: MARKETPLACES;
            previousSkuId: number;
            previousId: number;
            sellingPrice: number;
            paymentSystemName: string;
            paymentSystem: number;
        };
        products_specification: {
            id: number;
            productId: number;
            previousId: number;
            marketplaceId: MARKETPLACES;
            fieldId: number;
            fieldValueId: number;
            text: string;
            status: import("wecubedigital").ItemStatus;
        };
        sku_specification: {
            id: number;
            skuId: number;
            previousId: number;
            fieldId: number;
            fieldValueId: number;
            marketplaceId: MARKETPLACES;
            text: string;
            status: import("wecubedigital").ItemStatus;
        };
        sku_file: {
            id: number;
            sellerId: number;
            previousSellerId: string;
            archiveId: number;
            previousId: number;
            marketplaceId: MARKETPLACES;
            name: string;
            previousSkuId: number;
            skuId: number;
            isMain: number;
            url: string;
            label: string;
        };
        sku_attachment: {
            id: number;
            sellerId: number;
            previousSellerId: string;
            attachmentId: number;
            previousId: number;
            previousSkuId: number;
            marketplaceId: MARKETPLACES;
            skuId: number;
        };
        sellers: {
            id: number;
            urlLogo: string;
            name: string;
            email: string;
            marketplaceId: MARKETPLACES;
            previousId: string;
            description: string;
            exchangeReturnPolicy: string;
            deliveryPolicy: string;
            CNPJ: string;
            CSCIdentification: string;
            archiveId: number;
            productCommissionPercentage: number;
            freightCommissionPercentage: number;
            categoryCommissionPercentage: string;
            fulfillmentEndpoint: string;
            catalogSystemEndpoint: string;
            status: import("wecubedigital").ItemStatus;
            isBetterScope: boolean;
            merchantName: string;
            userName: string;
            customerId: string;
            useHybridPaymentOptions: boolean;
            isActive: boolean;
            fulfillmentSellerId: number;
            sellerType: number;
            trustPolicy: string;
        };
        seller_funds: {
            udpatedAt: number;
            id: number;
            balance: number;
        };
        seller_funds_history: {
            id: number;
            type: import("wecubedigital").SELLER_FUNDS_HISTORY_TYPE;
            sellerId: number;
            marketplaceId: MARKETPLACES;
            amount: number;
            status: import("wecubedigital").ItemStatus;
            createdAt: string;
            metadata: string | {
                eventId: string;
                payment: {
                    method: string;
                    stripeFee: number;
                    methodType: string;
                    intentId: string;
                    applicationFee: number;
                };
            };
        } | {
            id: number;
            type: import("wecubedigital").SELLER_FUNDS_HISTORY_TYPE;
            sellerId: number;
            status: import("wecubedigital").ItemStatus;
            marketplaceId: string;
            amount: number;
            createdAt: string;
            metadata: string | {
                id: number;
                campaignId: number;
                cpc: number;
            };
        };
        attachments: {
            id: number;
            name: string;
            previousId: number;
            isRequired: boolean;
            status: import("wecubedigital").ItemStatus;
            marketplaceId: MARKETPLACES;
            domains: {
                fieldName: string;
                maxCaraters: string;
                domainValues: string;
            }[];
        };
        sku_kit: {
            id: number;
            skuParentId: number;
            skuId: number;
            marketplaceId: MARKETPLACES;
            quantity: number;
            unitPrice: number;
            previousId: number;
        };
        brands: {
            id: number;
            name: string;
            status: import("wecubedigital").ItemStatus;
            title: string;
            metaTagDescription: string;
            imageUrl: string | null;
            previousId: number;
            marketplaceId: MARKETPLACES;
        };
        brand_context: {
            id: number;
            name: string;
            text: string;
            keywords: string;
            siteTitle: string;
            menuHome: boolean;
            adWordsRemarketingCode: string;
            lomadeeCampaignCode: string;
            previousId: number;
            status: import("wecubedigital").ItemStatus;
            marketplaceId: MARKETPLACES;
            linkId: string;
            brandId: number;
        };
        logging: {
            type: string;
            createdAt: Date;
            value: {};
        };
        vtex_sku_inventory: {
            id: string;
            skuId: number;
            warehouseId: string;
            totalQuantity: number;
            reservedQuantity: number;
            hasUnlimitedQuantity: number;
            availableQuantity: number;
            timeToRefill: string;
            leadTime: string;
            dateOfSupplyUtc: string;
            status: import("wecubedigital").ItemStatus;
            isUnlimited: boolean;
            previousSkuId: number;
            supplyLotId: string;
            marketplaceId: MARKETPLACES;
            keepSellingAfterExpiration: boolean;
            transfer: boolean;
            previousWarehouseId: string;
        };
        roles: {
            id: number;
            name: string;
            marketplaceId: MARKETPLACES;
            status: import("wecubedigital").ItemStatus;
            permissions: (1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 18 | 14 | 15 | 16 | 17 | 19 | 20 | 21 | 23 | 24 | 22)[];
        };
        categories: {
            previousId: number;
            marketplaceId: MARKETPLACES;
            id: number;
            name: string;
            title: string | null;
            description: string | null;
            isActive: boolean;
            keywords: string | null;
            status: import("wecubedigital").ItemStatus;
            lomadeeCampaignCode: string | null;
            adWordsRemarketingCode: string | null;
            showInStoreFront: boolean;
            showBrandFilter: boolean;
            activeStoreFrontLink: boolean;
            globalCategoryId: number;
            stockKeepingUnitSelectionMode: string;
            linkId: string;
            hasChildren: boolean;
            url: string;
            metaTagDescription: string | null;
            parent: number;
            previousParentId: number;
        };
        vtex_sku_attachment: {
            id: number;
            attachmentId: number;
            previousId: number;
            previousSkuId: number;
            marketplaceId: MARKETPLACES;
            skuId: number;
        };
        category_specification: {
            id: number;
            name: string;
            categoryId: number;
            marketplaceId: MARKETPLACES;
            previousId: number;
            isActive: boolean;
            fieldId: number;
            status: import("wecubedigital").ItemStatus;
            isStockKeepingUnit: boolean;
        };
        sku_price: {
            id: number;
            sellerId: number;
            previousSellerId: string;
            skuId: number;
            listPrice: number;
            marketplaceId: MARKETPLACES;
            previousSkuId: number;
            previousId: number;
            sellingPrice: number;
            paymentSystemName: string;
            paymentSystem: number;
        };
        sku_inventory: {
            id: number;
            skuId: number;
            previousSkuId: number;
            sellerId: number;
            previousSellerId: string;
            isUnlimited: boolean;
            marketplaceId: MARKETPLACES;
            availableQuantity: number;
            status: import("wecubedigital").ItemStatus;
        };
        ads: {
            id: number;
            marketplaceId: MARKETPLACES;
            isActive: boolean;
            status: import("wecubedigital").ItemStatus;
            isAvailable: boolean;
            campaignId: number;
            sellerId: number;
            type: import("wecubedigital").CAMPAIGN_TYPES;
            cpc: number;
            metadata?: string | Record<string, unknown> | undefined;
        };
        product_ads: {
            id: number;
            productId: number;
            skuId: number;
            metadata: string | {
                availableSkus: number[];
            };
        };
        banner_ads: {
            id: number;
            image_url: string;
            redirect_url: string;
        };
        interactions: {
            id: number;
            clicks: number;
            sold: number;
            cr: number;
            views: number;
            ctr: number;
        };
        interaction_history: {
            adId: number;
            status: import("wecubedigital").ItemStatus;
            marketplaceId: MARKETPLACES;
            sellerId: number;
            createdAt: string;
            metadata: {
                skuId: number;
                cpc: number;
            };
            type: import("wecubedigital").InteractionTypes;
            count: number;
            origin: string;
        };
        users: {
            marketplaceId: MARKETPLACES;
            sellerId: import("wecubedigital").SELLERS;
            id: string;
            status: import("wecubedigital").ItemStatus;
        };
        campaigns: {
            createdAt: string;
            id: number;
            name: string;
            startAt: string;
            endAt: string | undefined;
            status: import("wecubedigital").ItemStatus;
            marketplaceId: MARKETPLACES;
            isActive: boolean;
            placement: import("wecubedigital").CAMPAIGN_PLACEMENT;
            type: import("wecubedigital").CAMPAIGN_TYPES;
            sellerId: import("wecubedigital").SELLERS;
        };
        campaign_placement: {
            id: number;
            placement: import("wecubedigital").CAMPAIGN_PLACEMENT;
            page: string;
        };
        campaign_specification: {
            id: number;
            estimatedClicks: number;
        };
        campaign_payment: {
            id: number;
            paymentStatus: import("wecubedigital").PAYMENT_STATUS;
            totalBudget: number;
            dailyBudget: number;
            usedBudget: number;
            cpc: number;
            isDaily: boolean;
            dailyBudgetUsed: number;
        };
        credentials: {
            id: number;
            marketplaceId: MARKETPLACES;
            name: import("wecubedigital").CREDENTAIL_NAMES;
            credential: string;
        };
        sku_sellers: {
            urlLogo: string;
            name: string;
            email: string;
            marketplaceId: MARKETPLACES;
            previousId: string;
            description: string;
            exchangeReturnPolicy: string;
            deliveryPolicy: string;
            CNPJ: string;
            CSCIdentification: string;
            archiveId: number;
            productCommissionPercentage: number;
            freightCommissionPercentage: number;
            categoryCommissionPercentage: string;
            fulfillmentEndpoint: string;
            catalogSystemEndpoint: string;
            status: import("wecubedigital").ItemStatus;
            isBetterScope: boolean;
            merchantName: string;
            userName: string;
            customerId: string;
            useHybridPaymentOptions: boolean;
            isActive: boolean;
            fulfillmentSellerId: number;
            sellerType: number;
            trustPolicy: string;
        };
        orders: {
            previousId: string;
            createdAt: string;
            sellerId: number;
            previousSellerId: string;
            status: import("wecubedigital").ItemStatus;
            value: number;
            adId: number;
            skuId: number;
            productId: number;
            metadata: string | {
                cpc?: number | undefined;
            };
            marketplaceId: MARKETPLACES;
        };
    }[T];
}
export declare const ConversionNamesObj: ["attachments", "sku", "brands", "brand_context", "categories", "category_specification", "sku_price", "products_specification", "vtex_sku_attachment", "vtex_sku_file", "sku_inventory", "sku_specification", "vtex_sku", "vtex_products", "sku_kit", "sellers"];
export type ConversionNames = (typeof ConversionNamesObj)[number];
export type ConversionTableInfo = typeof ConversionTableObject;
export declare const BaseConversionInstanceItems: {
    readonly brands: ConversionInstance<"brands", string | number, string | number>;
    readonly categories: ConversionInstance<"categories", string | number, string | number>;
    readonly attachments: ConversionInstance<"attachments", string | number, string | number>;
    readonly brand_context: ConversionInstance<"brand_context", string | number, string | number>;
    readonly category_specification: ConversionInstance<"category_specification", string | number, string | number>;
    readonly sku_price: ConversionInstance<"sku_price", string | number, string | number>;
    readonly vtex_products: ConversionInstance<"vtex_products", string | number, string | number>;
    readonly products_specification: ConversionInstance<"products_specification", string | number, string | number>;
    readonly sellers: ConversionInstance<"sellers", number, string>;
    readonly vtex_sku: ConversionInstance<"vtex_sku", string | number, string | number>;
    readonly vtex_sku_attachment: ConversionInstance<"vtex_sku_attachment", string | number, string | number>;
    readonly vtex_sku_file: ConversionInstance<"vtex_sku_file", string | number, string | number>;
    readonly sku_inventory: ConversionInstance<"sku_inventory", string | number, string | number>;
    readonly sku_specification: ConversionInstance<"sku_specification", string | number, string | number>;
    readonly sku: ConversionInstance<"sku", string | number, string | number>;
    readonly sku_kit: ConversionInstance<"sku_kit", string | number, string | number>;
};
