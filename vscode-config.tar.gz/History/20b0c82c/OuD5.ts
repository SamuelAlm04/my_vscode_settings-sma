import { MARKETPLACES } from 'wecubedigital';
import { AvailableContextItems, ContextInstance, ContextQuery, SEARCH_MODE } from '../../types/contextTypes';
import { DatabaseQuery } from '../../types/storageType';
import { UserInstance } from '../Roles/User';
import { ItemContextMaker } from './contextItems/ItemContext';
import { MarketplaceContextMaker } from './contextItems/MarketplaceItemContext';
import { PrivateItemContextMaker } from './contextItems/PrivateItemContext';
import { DatabaseContextMaker } from './contextItems/DatabaseItemContext';
export declare function GetSearchModeMessage(mode: SEARCH_MODE): "in boolean mode" | "with query expansion" | "in natural language mode" | "in natural language mode with query expansion";
export declare class ContextFactory {
    static Builder: {
        FromParameters<T extends object>(query: object | import("qs").ParsedQs | URLSearchParams | null | undefined, tableItem?: T | undefined, props?: {
            strictPropertyNames?: boolean | undefined;
        } | undefined): import("../../types/contextTypes").ContextParameters<T>;
        Remove<T_1 extends object>(key: keyof import("../../types/contextTypes").ContextParameters<T_2>, item: import("../../types/contextTypes").ContextParameters<T_1>): any;
        Search<T_3 extends object>(item: object & {
            search_mode?: string | number | undefined;
        }, validItem: T_3, param: import("../../types/contextTypes").ContextParameters<T_3>, props?: {
            strictPropertyNames?: boolean | undefined;
        } | undefined): any;
        Select<K extends object>(item: object, tableItem: K, final: import("../../types/contextTypes").ContextParameters<K>): any;
        Order<Valid extends object>(item: object, final: import("../../types/contextTypes").ContextParameters<Valid>): any;
        WhereIn<Obj extends object, Key extends keyof Obj, Value extends Obj[Key]>(key: Key, value: Value | Value[], tableItem: Obj, final: import("../../types/contextTypes").ContextParameters<Obj>): any;
        Where<Obj_1 extends object, Key_1 extends keyof Obj_1, Value_1 extends Obj_1[Key_1]>(key: Key_1, value: Value_1, tableItem: Obj_1, final: import("../../types/contextTypes").ContextParameters<Obj_1>): any;
        Make<T_4 extends object>(item: object | import("qs").ParsedQs | null | undefined, tableItem?: T_4 | undefined, props?: {
            strictPropertyNames?: boolean | undefined;
        } | undefined): import("../../types/contextTypes").ContextParameters<T_4>;
    };
    private static readonly items;
    static Make<T extends AvailableContextItems>(name: T): {
        readonly attachments: (marketplaceId: MARKETPLACES, contextQuery: ContextQuery<"attachments">) => MarketplaceContextMaker<"attachments">;
        readonly marketplaces: (__: unknown, query: DatabaseQuery<"marketplaces">) => ItemContextMaker<object, "marketplaces">;
        readonly brands: (marketplaceId: MARKETPLACES, contextQuery: ContextQuery<"brands">) => MarketplaceContextMaker<"brands">;
        readonly brand_context: (marketplaceId: MARKETPLACES, contextQuery: ContextQuery<"brand_context">) => MarketplaceContextMaker<"brand_context">;
        readonly sku_price: (marketplaceId: MARKETPLACES, contextQuery: ContextQuery<"sku_price">) => MarketplaceContextMaker<"sku_price">;
        readonly sku_inventory: (marketplaceId: MARKETPLACES, contextQuery: ContextQuery<"sku_inventory">) => MarketplaceContextMaker<"sku_inventory">;
        readonly sku_attachment: (marketplaceId: MARKETPLACES, contextQuery: DatabaseQuery<"sku_attachment">) => MarketplaceContextMaker<"products" | "sku" | "vtex_sku" | "vtex_sku_file" | "marketplaces" | "marketplace_payment" | "domains" | "vtex_products" | "vtex_sku_price" | "products_specification" | "sku_specification" | "sku_file" | "sku_attachment" | "sellers" | "seller_funds" | "seller_funds_history" | "attachments" | "sku_kit" | "brands" | "brand_context" | "logging" | "vtex_sku_inventory" | "roles" | "categories" | "vtex_sku_attachment" | "category_specification" | "sku_price" | "sku_inventory" | "ads" | "product_ads" | "banner_ads" | "interactions" | "interaction_history" | "users" | "campaigns" | "campaign_placement" | "campaign_specification" | "campaign_payment" | "credentials" | "sku_sellers" | "orders">;
        readonly sku_file: (marketplaceId: MARKETPLACES, contextQuery: DatabaseQuery<"sku_attachment">) => MarketplaceContextMaker<"products" | "sku" | "vtex_sku" | "vtex_sku_file" | "marketplaces" | "marketplace_payment" | "domains" | "vtex_products" | "vtex_sku_price" | "products_specification" | "sku_specification" | "sku_file" | "sku_attachment" | "sellers" | "seller_funds" | "seller_funds_history" | "attachments" | "sku_kit" | "brands" | "brand_context" | "logging" | "vtex_sku_inventory" | "roles" | "categories" | "vtex_sku_attachment" | "category_specification" | "sku_price" | "sku_inventory" | "ads" | "product_ads" | "banner_ads" | "interactions" | "interaction_history" | "users" | "campaigns" | "campaign_placement" | "campaign_specification" | "campaign_payment" | "credentials" | "sku_sellers" | "orders">;
        readonly sku_kit: (marketplaceId: MARKETPLACES, contextQuery: DatabaseQuery<"sku_kit">) => MarketplaceContextMaker<"products" | "sku" | "vtex_sku" | "vtex_sku_file" | "marketplaces" | "marketplace_payment" | "domains" | "vtex_products" | "vtex_sku_price" | "products_specification" | "sku_specification" | "sku_file" | "sku_attachment" | "sellers" | "seller_funds" | "seller_funds_history" | "attachments" | "sku_kit" | "brands" | "brand_context" | "logging" | "vtex_sku_inventory" | "roles" | "categories" | "vtex_sku_attachment" | "category_specification" | "sku_price" | "sku_inventory" | "ads" | "product_ads" | "banner_ads" | "interactions" | "interaction_history" | "users" | "campaigns" | "campaign_placement" | "campaign_specification" | "campaign_payment" | "credentials" | "sku_sellers" | "orders">;
        readonly ads: (contextQuery: ContextQuery<"ads">) => PrivateItemContextMaker<"ads">;
        readonly product_ads: (__: unknown, query: DatabaseQuery<"product_ads">) => DatabaseContextMaker<"product_ads">;
        readonly roles: (marketplaceId: MARKETPLACES, contextQuery: ContextQuery<"roles">) => MarketplaceContextMaker<"roles">;
        readonly products: (contextQuery: ContextQuery<"products">) => PrivateItemContextMaker<"products">;
        readonly domains: (marketplaceId: MARKETPLACES, contextQuery: ContextQuery<"brands">) => MarketplaceContextMaker<"brands">;
        readonly campaigns: (contextQuery: ContextQuery<"campaigns">) => PrivateItemContextMaker<"campaigns">;
        readonly sku: (contextQuery: ContextQuery<"sku">) => PrivateItemContextMaker<"sku">;
        readonly orders: (contextQuery: ContextQuery<"orders">) => PrivateItemContextMaker<"orders">;
        readonly credentials: (marketplaceId: MARKETPLACES, contextQuery: ContextQuery<"credentials">) => MarketplaceContextMaker<"credentials">;
        readonly categories: (marketplaceId: MARKETPLACES, contextQuery: ContextQuery<"categories">) => MarketplaceContextMaker<"categories">;
        readonly category_specification: (marketplaceId: MARKETPLACES, contextQuery: ContextQuery<"category_specification">) => MarketplaceContextMaker<"category_specification">;
        readonly sellers: (marketplaceId: MARKETPLACES, contextQuery: ContextQuery<"sellers">) => MarketplaceContextMaker<"sellers">;
        readonly seller_funds_history: (contextQuery: ContextQuery<"seller_funds_history">) => PrivateItemContextMaker<"seller_funds_history">;
    }[T];
    static fromRequest<T extends AvailableContextItems>(name: T, query: DatabaseQuery<T>, request: {
        user: UserInstance;
    }): ContextInstance<T>;
}
