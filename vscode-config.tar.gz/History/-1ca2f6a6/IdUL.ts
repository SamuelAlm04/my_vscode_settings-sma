import { NextFunction, Request, Response, Router } from 'express';
import { Tspec } from 'tspec';
import {
    BrandInfo,
    ItemStatus,
    NewBrandInfo,
    NewBrandInfoObject,
    RolePermission,
    UpdatingBrandInfo,
} from 'wecubedigital';
import { logging } from '../../Logging/Log';
import { Managers } from '../../Managers/Managers';
import {
    BadRequestError,
    InternalError,
    InvalidItemError,
    NotFoundError,
} from '../../lib/ErrorHandling/ErrorHandler';
import { Formatter } from '../../lib/Formatter';
import { ItemTreater } from '../../lib/ItemHandling/ItemTreater';
import { permissionsHandler } from '../../lib/Roles/permissionManager';
import { ContextBuilder } from '../../lib/context/ContextBuilder';
import { ContextFactory } from '../../lib/context/DatabaseContext';
import {
    ApiDeleteStatus,
    ApiGetStatus,
    ApiPostStatus,
    ApiUpdateStatus,
    QueryFilter,
} from '../../types/backendTypes';
import { Validation } from '../../lib/Validation/Validation';
import {
    ERROR_CODES,
    ItemPropertyValidator,
} from '../../lib/Validation/ItemValidation/itemValidation';
import { ValidationCluster } from '../../lib/Validation/ItemValidation/ItemValidationCluster';

export const brandRouter: Router = Router();

brandRouter.use('/', (req, res, next) =>
    permissionsHandler.validateRoute(RolePermission.BRAND, req, res, next),
);

type BrandRequest = Request<{ brandId: string }>;
type UpdateBrandRequest = Request<{ brandId: string }, unknown, NewBrandInfo>;
type NewBrandRequest = Request<{ brandId: string }, unknown, NewBrandInfo>;

export const BrandsController = {
    getBrands: async (req: Request, res: Response<BrandInfo[]>) => {
        const brandQuery = ContextFactory.fromRequest(
            'brands',
            Managers.get('brands').Context(),
            req,
        )
            .SetParameters(
                ContextBuilder.FromParameters(req.query, NewBrandInfoObject),
            )
            .Build();
        //const brandQuery = ContextFactory.Make('brands')(
        //        req.user.marketplaceId,
        //        Managers.get('brands').Context()
        //    )
        //        .SetIgnoreStatus(req.user.getIngoreStatus())
        //        .SetParameters(
        //            ContextBuilder.Make(req.query, NewBrandInfoObject)
        //        )
        //        .Build()
        const allBrands = await Managers.get('brands').getAll(brandQuery);

        res.json(allBrands);
    },
    BrandMiddleware: async (
        req: BrandRequest,
        _: Response,
        next: NextFunction,
    ) => {
        if (!('brandId' in req.params) || !req.params.brandId) {
            throw new BadRequestError('Brand Id must be provided');
        }

        const brandId = Number(req.params.brandId);

        const brandManager = Managers.get('brands');

        if (!brandId)
            return next(new BadRequestError('Brand Id Must be a number'));

        const brand = await brandManager.getById(
            brandId,
            ContextFactory.fromRequest('brands', brandManager.Context(), req)
                .SetParameters(
                    ContextBuilder.FromParameters(
                        req.query,
                        NewBrandInfoObject,
                    ),
                )
                .Build(),
        );

        if (!brand) return next(new NotFoundError('Brand not found'));

        //if (brand.marketplaceId !== req.user.marketplaceId)
        //    return next(new UnauthorizedError('Invalid MarketplaceId'));

        req.brand = brand;

        next();
    },
    getBrand: (req: BrandRequest, res: Response<BrandInfo>) => {
        return res.json(req.brand);
    },
    updateBrand: async (req: UpdateBrandRequest, res: Response<BrandInfo>) => {
        const brandManager = Managers.get('brands');

        const brandTreater = new ItemTreater<UpdatingBrandInfo>()
            .add((item) => {
                item.status = item.status || ItemStatus.ACTIVE;
            })
            .add((item) => {
                item.previousId = req.brand!.previousId! || 0;
            });

        const cleanedBrand = brandTreater.treat(
            Formatter.cleanObject<UpdatingBrandInfo>(
                req.body,
                NewBrandInfoObject,
            ),
        );

        const brandValidator = new ItemPropertyValidator<NewBrandInfo>()
            .add(
                (item) => item.status && Formatter.isValidStatus(item.status),
                (item) =>
                    Validation.messages.new(
                        `${item.status} is not a valid status`,
                        ERROR_CODES.INVALID,
                    ),
            )

            .add(
                (item) => {
                    if (item.imageUrl && typeof item.imageUrl === 'string') {
                        return Formatter.isValidUrl(item.imageUrl);
                    }
                    return true;
                },
                (item) =>
                    Validation.messages.new(
                        `${item.imageUrl} is not a valid url`,
                        ERROR_CODES.INVALID,
                    ),
            )

            .add(
                (item) => item.imageUrl && Formatter.isValidUrl(item.imageUrl),
                Validation.messages.invalid(
                    'image url',
                    'url',
                    ERROR_CODES.INVALID,
                ),
            )
            .add(
                (item) => item.marketplaceId,
                Validation.messages.new(
                    'invalid MarketplaceId',
                    ERROR_CODES.INVALID,
                ),
            );

        const hasErrors = brandManager.hasErrors(
            cleanedBrand,
            NewBrandInfoObject,
            brandValidator,
        );

        if (hasErrors) {
            throw new InvalidItemError(hasErrors.getErrors());
        }

        const updatedBrand = await brandManager.update(
            req.brand!.id!,
            cleanedBrand,
        );

        if (!updatedBrand)
            throw new InternalError('Error while updating Brand');

        logging.add('brands:put', {
            id: updatedBrand.id,
            creator: req.user!.info.id,
        });

        res.json(updatedBrand);
    },
    async deleteBrand(req: BrandRequest, res: Response<boolean>) {
        const deleted = await Managers.get('brands').hide(req.brand!.id!);

        logging.add('brands:delete', {
            id: req.brand!.id,
            creator: req.user!.info.id,
        });

        res.json(deleted);
    },
    async newBrand(req: NewBrandRequest, res: Response<BrandInfo>) {
        const brandManager = Managers.get('brands');

        const brandTreater = new ItemTreater<NewBrandInfo>()
            .add((item) => {
                item.marketplaceId ||= req.user.marketplaceId;
            })
            .add((item) => {
                item.status = item.status ? item.status : ItemStatus.ACTIVE;
            });

        const cleanedBrand = brandTreater.treat(
            Formatter.cleanObject<NewBrandInfo>(req.body, NewBrandInfoObject),
        );

        const BrandValidator = new ValidationCluster<NewBrandInfo>().add(
            new ItemPropertyValidator<NewBrandInfo>()
               
                .add(
                    (item) =>
                        item.status && Formatter.isValidStatus(item.status),

                    (item) =>
                        Validation.messages.new(
                            `${item.status} is not a valid status`,
                            ERROR_CODES.INVALID,
                        ),
                )
                .add(
                    (item) => item.marketplaceId,
                    Validation.messages.new(
                        'invalid MarketplaceId',
                        ERROR_CODES.INVALID,
                    ),
                ),
        );

        const hasErrors = brandManager.hasErrors(
            cleanedBrand,
            NewBrandInfoObject,
            BrandValidator,
        );

        if (hasErrors) {
            throw new InvalidItemError(hasErrors.getErrors());
        }

        const newBrand = await brandManager.upload(cleanedBrand);

        if (!newBrand) throw new InternalError('Error while uploading Brand');

        logging.add('brands:post', {
            id: newBrand.id,
            creator: req.user!.info.id,
        });

        res.json(newBrand);
    },
};

export type BrandDefs2 = Tspec.DefineApiSpec<{
    basePath: '/brands';
    paths: {
        '/': {
            get: {
                query: QueryFilter<Omit<BrandInfo, 'imageUrl'>>;
                responses: ApiGetStatus<{ 200: BrandInfo[] }>;
                handler: typeof BrandsController.getBrands;
            };
            post: {
                responses: ApiPostStatus<{ 200: BrandInfo }>;
                handler: typeof BrandsController.newBrand;
            };
        };
        '/{brandId}': {
            get: {
                responses: ApiGetStatus<{ 200: BrandInfo }>;
                handler: typeof BrandsController.getBrand;
            };
            put: {
                responses: ApiUpdateStatus<{ 200: BrandInfo }>;
                handler: typeof BrandsController.updateBrand;
            };
            delete: {
                responses: ApiDeleteStatus<{ 200: BrandInfo }>;
                handler: typeof BrandsController.deleteBrand;
            };
        };
    };
}>;

brandRouter.get('/', BrandsController.getBrands);

brandRouter.use('/:brandId', BrandsController.BrandMiddleware);

brandRouter.get('/:brandId', BrandsController.getBrand);
brandRouter.put('/:brandId', BrandsController.updateBrand);
brandRouter.delete('/:brandId', BrandsController.deleteBrand);
brandRouter.post('/', BrandsController.newBrand);
