import { connection } from 'src/db';
import { describe, it } from 'vitest';
import { ItemStatus } from 'wecubedigital';
import { z } from 'zod'

describe('Campaign new request test', () => {
    it('GET - New Request', async () => {
        const campaignRequestSchema = z.object({
            campaignId: z.number(),
            id: z.number(),
            skuId: z.number(),
            status: z.number(),
            isActive: z.boolean(),
            sold: z.number(),
            views: z.number(),
            clicks: z.number(),
            ctr: z.string(),
            cr: z.string(),
            cpc: z.number(),
            productId: z.number(),
            productName: z.string(),
            linkId: z.string(),
            listPrice: z.number(),
            availableQuantity: z.number(),
            imageUrl: z.string()
        })
        const campaignID = await connection('campaigns').select('id').where('status', ItemStatus.ACTIVE)
        console.log(campaignID)
    })
})