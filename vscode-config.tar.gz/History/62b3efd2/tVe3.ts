import { App } from '__tests__/vitest.setup';
import { TESTING_ACCESS_TOKEN } from 'src/constants';
import { connection } from 'src/db';
import { HTTPCodes } from 'src/lib/ErrorHandling/ErrorHandler';
import { describe, it, expect } from 'vitest';
import { ItemStatus, MARKETPLACES, SELLERS } from 'wecubedigital';
import { z } from 'zod';

describe('Campaign new request test', () => {
    it('GET - New Request', async () => {
        // estrutura campaign
        const campaignRequestSchema = z.object({
            campaignId: z.number(),
            id: z.number(),
            skuId: z.number(),
            status: z.number(),
            isActive: z.boolean(),
            sold: z.number(),
            views: z.number(),
            clicks: z.number(),
            ctr: z.string(),
            cr: z.string(),
            cpc: z.number(),
            productId: z.number(),
            productName: z.string(),
            linkId: z.string(),
            listPrice: z.number(),
            availableQuantity: z.number(),
            imageUrl: z.string(),
        });
        //pega ID
        const campaignID = await connection('campaigns')
            .select('id')
            .where('status', ItemStatus.ACTIVE)
            .andWhere('marketplaceId', MARKETPLACES.TESTING)
            .andWhere('sellerId', SELLERS.CUBE)
            .first();

        
        //pega as campanhas com a ID
        const response = await App!
            .get(
                `/api/dashboard/seller/campaign/${campaignID?.id}?date=2021-01-01,2027-06-06&type=1&limit=10&offset=0`
            )
            .set('Authorization', TESTING_ACCESS_TOKEN);
        


        // Σ sold  Σ views Σ clicks
        // const sum = response.body.reduce(
        //     (acc: number, total: { views: })
        // );

        console.log(response.body);
        expect(response.status).toEqual(HTTPCodes.OK);
    });
});
