import { App } from '__tests__/vitest.setup';
import { TESTING_ACCESS_TOKEN } from 'src/constants';
import { connection } from 'src/db';
import { HTTPCodes } from 'src/lib/ErrorHandling/ErrorHandler';
import { DateFormatter } from 'src/lib/Formatter/Date';
import { describe, expect, it } from 'vitest';
import {
    ItemStatus,
    MARKETPLACES,
    SELLER_FUNDS_HISTORY_TYPE,
    SellerFundsHistory,
    SELLERS,
} from 'wecubedigital';

function get() {
    return connection('seller_funds_history')
        .select('sellerId', 'createdAt')
        .sum('amount as amount')
        .where('sellerId', SELLERS.CUBE)
        .andWhere('marketplaceId', MARKETPLACES.TESTING)
        .andWhere('type', SELLER_FUNDS_HISTORY_TYPE.CREDITS)
        .andWhere('status', ItemStatus.ACTIVE)
        .andWhere('createdAt', '>=', '2021-01-01')
        .andWhere('createdAt', '<=', '2026-05-04')
        .groupByRaw(
            connection.raw(DateFormatter.format(connection.client, 'createdAt'))
        )
        .groupBy('sellerId');
}
describe('api seller financial router tests', () => {
    it('tests all the sums', async () => {
        const [credits, response] = await Promise.all([
            get() as Promise<Pick<SellerFundsHistory, 'sellerId' | 'amount'>[]>,
            App.get(
                '/api/dashboard/seller/financial/funds?date=2021-01-01,2026-05-04&limit=10&offset=0'
            ).set('Authorization', `Bearer ${TESTING_ACCESS_TOKEN}`),
        ]);

        const sumresponse = response.body.data.reduce(
            (acc: number, item: { count: number }) => {
                return acc + item.count;
            },
            0
        );

        const sumcredits = credits.reduce((acc: number, item) => {
            return acc + item.amount;
        }, 0);

        expect(sumresponse).toEqual(sumcredits);
        expect(response.status).toEqual(HTTPCodes.OK);
        expect(response.body.data.length).greaterThanOrEqual(
            response.body.info.total
        );
    });
    it('tests all available', async () => {
        const available = await connection('seller_funds_history')
            .where('sellerId', SELLERS.CUBE)
            .andWhere('marketplaceId', MARKETPLACES.TESTING)
            .andWhere('status', ItemStatus.ACTIVE)
            .select('sellerId', 'createdAt', 'marketplaceId')
            .sum('amount as amount')
            .groupByRaw(
                connection.raw(
                    DateFormatter.format(connection.client, 'createdAt')
                )
            )
            .groupBy('sellerId');

        const sumAvailable = available.reduce(
            (acc: number, total: { amount: number }) => {
                return (acc += total.amount);
            },
            0
        );

        const response = await App.get(
            '/api/dashboard/seller/financial/available?date=2021-01-01,2026-05-04&limit=10&offset=0'
        ).set('Authorization', TESTING_ACCESS_TOKEN);

        const sumResponse = response.body.reduce(
            (acc: number, total: { count: number }) => {
                return (acc += total.count);
            },
            0
        );

        expect(response.body.length).toBeGreaterThan(0);
        expect(response.body).toBeTypeOf('object');
        expect(sumAvailable).toEqual(sumResponse);
        expect(response.status).toEqual(HTTPCodes.OK);
    });
    it('tests all sold', async () => {
        const sold = await connection('orders')
            .where('sellerId', SELLERS.CUBE)
            .andWhere('marketplaceId', MARKETPLACES.TESTING)
            .andWhere('status', ItemStatus.ACTIVE)
            .andWhere('createdAt', '>=', '2021-01-01')
            .andWhere('createdAt', '<=', '2026-05-04')
            .select('sellerId', 'createdAt', 'marketplaceId')
            .sum('value as count')
            .groupByRaw(
                connection.raw(
                    DateFormatter.format(connection.client, 'createdAt')
                )
            )
            .groupBy('sellerId');

        const response = await App.get(
            '/api/dashboard/seller/financial/sold?date=2021-01-01,2026-05-04&limit=10&offset=0'
        ).set('Authorization', TESTING_ACCESS_TOKEN);

        const sumSold = sold.reduce((acc: number, total: { count: number }) => {
            return (acc += total.count);
        }, 0);
        const sumResponse = response.body.data.reduce(
            (acc: number, total: { count: number }) => {
                return (acc += total.count);
            },
            0
        );

        expect(response.body.data.length).toEqual(response.body.info.total);
        expect(response.body.data).toBeTypeOf('object');
        expect(sumSold).toEqual(sumResponse);
        expect(response.status).toEqual(HTTPCodes.OK);
    });
    it('tests the invested', async () => {
        const invested = await connection('seller_funds_history')
            .select('sellerId', 'marketplaceId', 'createdAt')
            .where('status', ItemStatus.ACTIVE)
            .andWhere('sellerId', SELLERS.CUBE)
            .andWhere('marketplaceId', MARKETPLACES.TESTING)
            .andWhere('type', SELLER_FUNDS_HISTORY_TYPE.Ad)
            .andWhere('createdAt', '>=', '2021-01-01')
            .andWhere('createdAt', '<=', '2026-05-04')
            .sum('amount as count')
            .groupByRaw(
                connection.raw(
                    DateFormatter.format(connection.client, 'createdAt')
                )
            )
            .groupBy('sellerId');

        const response = await App.get(
            '/api/dashboard/seller/financial/invested?date=2021-01-01,2026-05-04&limit=10&offset=0'
        ).set('Authorization', TESTING_ACCESS_TOKEN);

        const sumInvested = invested.reduce(
            (acc: number, total: { count: number }) => {
                return (acc += total.count);
            },
            0
        );
        const sumResponse = response.body.data.reduce(
            (acc: number, total: { count: number }) => {
                return (acc += total.count);
            },
            0
        );

        expect(sumResponse).toEqual(sumInvested);
        expect(response.status).toEqual(HTTPCodes.OK);
        expect(response.body.data.length).toEqual(response.body.info.total);
        expect(response.body.data).toBeTypeOf('object');
    });
    it.only('tests the financial', async () => {
        const response = await App!
            .get('/api/dashboard/seller/financial/?date=2021-01-01,2026-05-04')
            .set('Authorization', TESTING_ACCESS_TOKEN);

        expect(response.body.data.length).toEqual(response.body.info.total);
        expect(response.body.data.length).toBeGreaterThan(0);
        const queryOne = await connection('seller_funds_history')
            .sum('amount AS amount')
            .where('status', ItemStatus.ACTIVE)
            .where('type', SELLER_FUNDS_HISTORY_TYPE.Ad)
            .where('marketplaceId', MARKETPLACES.TESTING)
            .where('sellerId', SELLERS.CUBE);

        console.log(queryOne);
    });
});
