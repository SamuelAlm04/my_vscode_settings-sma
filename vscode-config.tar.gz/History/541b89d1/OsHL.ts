import { App } from '__tests__/vitest.setup';
import { API_ACCESS_TOKEN, TESTING_ACCESS_TOKEN } from 'src/constants';
import { describe, expect, it } from 'vitest';
import { MARKETPLACES } from 'wecubedigital';

const baseUrl =
    '/api/dashboard/seller/financial/invested?date=2021-06-25,2027-06-06&limit=19';
describe('SELLER FINANCIAL FUNDS - IMPERSONATION', () => {
    //GET ALL
    it('GET - All - Same Seller', async () => {
        const ads = await App!
            .get(baseUrl)
            .set('Authorization', TESTING_ACCESS_TOKEN);

        expect(ads.body.data.length > 0).toEqual(true);

        expect(
            ads.body.data.every(
                (item: { marketplaceId: MARKETPLACES }) =>
                    item.marketplaceId === MARKETPLACES.TESTING,
            ),
        ).toEqual(true);
    });

    it('GET - All - Other Seller', async () => {
        const ads = await App!
            .get(`${baseUrl}&sellerId=2`)
            .set('Authorization', TESTING_ACCESS_TOKEN);
        //  console.error(ads)
        expect(ads.body.data.length).toEqual(0);
    });
    it('GET -  wrong marketplace', async () => {
        const p = await App!
            .get(`${baseUrl}&marketplaceId=${MARKETPLACES.WECODE}`)
            .set('Authorization', TESTING_ACCESS_TOKEN);
        //console.error(p.status, p)
        expect(p.body.data.length).toEqual(0);
    });

    it('GET - API - ALL', async () => {
        const apiProducts = await App!
            .get(`${baseUrl}&marketplaceId=${MARKETPLACES.WECODE}`)
            .set('Authorization', API_ACCESS_TOKEN);
        expect.soft(apiProducts.body.data.length).greaterThan(0);
        //console.error(apiProducts.body.data)
        expect(
            apiProducts.body.data.every(
                (item: { marketplaceId: MARKETPLACES }) =>
                    item.marketplaceId === MARKETPLACES.WECODE,
            ),
        ).toEqual(true);
    });
    it('GET - API - ALL from other marketplace', async () => {
        const apiOtherMk = await App!
            .get(`${baseUrl}&marketplaceId=${MARKETPLACES.TESTING}`)
            .set('Authorization', API_ACCESS_TOKEN);
        expect.soft(apiOtherMk.body.data.length).greaterThan(0);
        expect(
            apiOtherMk.body.data.every(
                (item: { marketplaceId: MARKETPLACES }) =>
                    item.marketplaceId === MARKETPLACES.TESTING,
            ),
        ).toEqual(true);
    });
});
