import { Response } from 'supertest';
import { App } from '__tests__/vitest.setup';
import { TESTING_ACCESS_TOKEN } from 'src/constants';
import { HTTPCodes } from 'src/lib/ErrorHandling/ErrorHandler';
import { describe, it, expect, beforeAll } from 'vitest';
import { ProductInfo } from 'wecubedigital';

let product: ProductInfo;
let response: Response;
let productresponse: Response;
beforeAll(async () => {
    response = await App?.get('/products').set(
        'Authorization',
        TESTING_ACCESS_TOKEN,
    );

    product = response.body[0];
    productresponse = await App?.get(`/products/${product.id}`).set(
        'Authorization',
        TESTING_ACCESS_TOKEN,
    );
});

describe('teste de rotas de produtos', () => {
    it('GET - All', () => {
        // expect(1 + 1 ).equals(2)
        expect(response.body.length).greaterThan(0);

        expect(response.status).toEqual(HTTPCodes.OK);
    });
    it('GET - SKU by product', async () => {
        const response = await App.get(`/products/${product.id}/sku`).set(
            'Authorization',
            TESTING_ACCESS_TOKEN,
        );

        expect(response.body.length).greaterThan(0);

        expect(response.status).toEqual(HTTPCodes.OK);
    });
    it('GET - Only one', () => {
        // expect(1 + 1 ).equals(2)
        expect(productresponse.body).toBeTypeOf('object');
        expect(productresponse.status).toEqual(HTTPCodes.OK);
    });
    it('POST - Product', async () => {
        product.showWithoutStock = Boolean(product.showWithoutStock)
        const response = await App!.post('/products')
        .set('Authorization', TESTING_ACCESS_TOKEN)
        .send(product)

        console.log(product)

        expect(response.body).toBeTypeOf('object')
        expect(response.status).toEqual(HTTPCodes.OK)
    })
    it('UPDATE - Product', async () => {
        const response = await App.put(`/products/${product.id}`)
            .set('Authorization', TESTING_ACCESS_TOKEN)
            .send(product);

        expect(response.body).toBeTypeOf('object');
        expect(response.status).toEqual(HTTPCodes.OK);
    });
});

