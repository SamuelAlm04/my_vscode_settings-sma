import { App } from '__tests__/vitest.setup'
import { TESTING_ACCESS_TOKEN } from 'src/constants'
import { HTTPCodes } from 'src/lib/ErrorHandling/ErrorHandler'
import { describe, it, expect, } from 'vitest'

describe('tests the validity of the marketplace stats', () => {
    it.todo('tests the sold ', async () => { 
        
    })
    it.todo('tests the views ', async () => { 

    })
    it('tests the clicks ', async () => { 
        const response = await App!.get('/api/dashboard/seller/campaigns/stats/clicks?type=clicks&date=2024-02-20,2029-03-14&campaign_type=1&limit=10&offset=10')
        .set('Authorization', TESTING_ACCESS_TOKEN)

        expect(response.status).toEqual(HTTPCodes.OK)
        console.log(response.body)
    })
    it.todo('tests the invested ', () => { 

    })
    it.todo('tests the invested ', () => { 

    })
    it.todo('tests the impersonation', () => {})
})
