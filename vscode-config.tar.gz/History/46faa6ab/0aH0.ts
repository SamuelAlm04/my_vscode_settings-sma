import { describe, it, } from 'vitest'

describe('tests the validity of the marketplace stats', () => {
    it.todo('tests the sold ', () => { })
    it.todo('tests the views ', () => { })
    it.todo('tests the clicks ', () => { })
    it.todo('tests the invested ', () => { })
    it.todo('tests the invested ', () => { })
    it.todo('tests the impersonation', () => { })
})
