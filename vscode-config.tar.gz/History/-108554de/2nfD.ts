import { Request, Response, Router } from 'express';
import { Tspec } from 'tspec';
import { ItemStatus } from 'wecubedigital';
import { Managers } from '../../../../Managers/Managers';
import { DEFAULTS, UNWANTED_STATUSES } from '../../../../constants';
import {
    BadRequestError,
    HTTPCodes,
} from '../../../../lib/ErrorHandling/ErrorHandler';
import { Formatter } from '../../../../lib/Formatter';
import { ItemTreater } from '../../../../lib/ItemHandling/ItemTreater';
import {
    ChronoQuery,
    TimeResult,
    TimeSeries,
} from '../../../../lib/chrono/ChronoQuery';
import { ContextBuilder } from '../../../../lib/context/ContextBuilder';
import { ContextFormatter } from '../../../../lib/context/ContextFormatter';
import { ItemContextMaker } from '../../../../lib/context/contextItems/ItemContext';
import { Pagination } from '../../../../lib/pagination/Pagination';
import { connection } from '../../../../server';
import {
    ApiGetStatus,
    ApiPostStatus,
    ToQuery,
} from '../../../../types/backendTypes';
import { ContextParameters } from '../../../../types/contextTypes';
import {
    MarketplaceSellerDashboard,
    MarketplaceSellerResponseObject,
    SellerDashboardResponse,
    sellerResponseStringKeys,
} from '../../../../types/dasboardTypes';
import {
    PaginatedQuery,
    PaginationProps,
} from '../../../../types/paginationType';
import { DatabaseQuery } from '../../../../types/storageType';
import Clicks from './stats/Clicks';
import Invested from './stats/Invested';
import Revenue from './stats/Revenue';
import Sold from './stats/Sold';
import Views from './stats/Views';
import { ContextFactory } from '../../../../lib/context/DatabaseContext';

const DashboardRouter = Router();

function FormatDate() {
    const now = new Date(Date.now());
    return `${now.getFullYear()}-${now.getMonth()}-${now.getDay()}`;
}

function MakeSellerDashboardQuery(
    query: DatabaseQuery<'sellers'>,
    params: ContextParameters<MarketplaceSellerDashboard> & PaginationProps,
    pagination: Pagination,
): Promise<PaginatedQuery<MarketplaceSellerDashboard[]>> {
    query
        .select(
            'sellers.id',
            'sellers.isActive',
            'sellers.name',
            'sellers.marketplaceId',
            connection.raw('COALESCE(ord.sellerId,0) as sold'),
            connection.raw('COALESCE(sum(ord.earnings),0) as earnings'),
            connection.raw(
                'coalesce(sum(camp.active_campaigns),0) as active_campaigns',
            ),
            connection.raw('coalesce(sf.invested, 0) as invested'),
            connection.raw('coalesce(ih.views,0) as views'),
            connection.raw('coalesce(ih.clicks,0) as clicks'),
            connection.raw('coalesce(ih.clicks / ih.views,0) as ctr'),
            connection.raw('coalesce(ord.sellerId / ih.views, 0) as cr'),
        )
        .leftJoin(
            connection.raw(
                `(select coalesce(count(campaigns.id), 0) as active_campaigns, sellerId
                       from campaigns
                       where campaigns.status = ?
                       and campaigns.isActive = ?
                       group by sellerId) as camp`,
                [ItemStatus.ACTIVE, true],
            ),
            'sellers.id',
            'camp.sellerId',
        )
        .leftJoin(
            connection.raw(
                `(select count(orders.id), sellerId, sum(orders.value) as earnings
                       from orders
                       where orders.status not in (?)
                       group by sellerId) as ord`,
                [UNWANTED_STATUSES],
            ),
            'ord.sellerId',
            'sellers.id',
        )
        .leftJoin(
            connection.raw(
                `(select sum(amount) as invested, sellerId
                       from seller_funds_history
                       group by sellerId) as sf`,
            ),
            'sellers.id',
            'sf.sellerId',
        )
        .leftJoin(
            connection.raw(
                `(select ads.sellerId,
                              SUM(CASE WHEN interaction_history.type = 'clicks' THEN count END) AS clicks,
                              SUM(CASE WHEN interaction_history.type = 'views' THEN count END) AS views
                       from ads
                       inner join interaction_history on ads.id = interaction_history.adId
                       where ads.status not in ( ? )
                       group by ads.sellerId) as ih`,
                [UNWANTED_STATUSES],
            ),
            'ih.sellerId',
            'sellers.id',
        )
        .andWhere('sellers.status', 'not in', UNWANTED_STATUSES)
        .andWhere('sellers.isActive', true)
        .groupBy('sellers.id', 'active_campaigns');

    const builded = new ItemContextMaker(query).SetParameters(params).Build();
    return pagination.Result<MarketplaceSellerDashboard[]>(builded);
}

export type SellerCampaignTimeSeries = ToQuery<TimeSeries>;

export type SellerRequest = Request<
    unknown,
    unknown,
    unknown,
    SellerCampaignTimeSeries
>;

class MarketplaceRouter {
    private static QueryTreater = new ItemTreater<
        object & ContextParameters<MarketplaceSellerDashboard>,
        ContextParameters<MarketplaceSellerDashboard>
    >().add((item) => {
        if (!('limit' in item)) {
            item.limit = DEFAULTS.PAGINATION.LIMIT;
        }
        if (!('offset' in item)) {
            item.offset = DEFAULTS.PAGINATION.OFFSET;
        }

        item.orders ||= [
            //@ts-expect-error change typescript
            { column: 'sellers.id', order: DEFAULTS.PAGINATION.ORDER },
        ];

        return item;
    });

    static async GetSellerSold_POST(
        req: Request<unknown, unknown, ToQuery<SellerCampaignTimeSeries>>,
        res: Response<TimeResult[]>,
    ) {
        const chrono = new ChronoQuery();

        const timeSeries = chrono.toTimeSeries(req.query);

        const s = (await chrono.getSold(
            timeSeries,
            Managers.get('orders')
                .Context()
                .where('marketplaceId', req.user.marketplaceId),
        )) as unknown as TimeResult[];

        return res.json(s);
    }

    static Convert(sellers: MarketplaceSellerDashboard[]) {
        for (let index = 0; index < sellers.length; index++) {
            const element = sellers[index];
            if (!element) continue;

            for (let i = 0; i < sellerResponseStringKeys.length; i++) {
                const key = sellerResponseStringKeys[i];
                if (!key) continue;

                if (
                    key in element &&
                    element[key] &&
                    typeof element[key] === 'string'
                ) {
                    //@ts-expect-error tscript
                    element[key] = Number(element[key]);
                }
            }
        }
    }

    static GetSellersFromQuery(
        req: Request<unknown, unknown, ToQuery<MarketplaceSellerDashboard>>,
        res: Response<SellerDashboardResponse>,
    ) {
        /**
         * Desculpa se tem bug aqui...
         * Pode me chamar e eu vou parar qualquer coisa que to fazendo pra te ajudar.
         *    rodrigo - 11 jun 2024
         */
        const context = ContextBuilder.Make<MarketplaceSellerDashboard>(
            //new ContextFormatter(
            MarketplaceRouter.QueryTreater.treat(
                Formatter.QueryToObject(req.query),
            ),
            //).SwapValues({ name: 'sellers.name' }),
            MarketplaceSellerResponseObject,
        );

        Pagination.SetDefaults(context, {
            limit: DEFAULTS.PAGINATION.LIMIT,
            offset: DEFAULTS.PAGINATION.OFFSET,
        });

        if (context.limit < 0) {
            throw new BadRequestError('invalid limit');
        }
        if (context.offset < 0) {
            throw new BadRequestError('invalid offset');
        }

        const query = ContextFactory.fromRequest(
            'sellers',
            connection('sellers'),
            req,
        )
            .SetParameters(context)
            .Build();

        return MarketplaceRouter.GetSellers(context, query, res);
    }

    static GetSellersFromBody(
        req: Request<unknown, unknown, ToQuery<MarketplaceSellerDashboard>>,
        res: Response<SellerDashboardResponse>,
    ) {
        const context = ContextBuilder.Make<MarketplaceSellerDashboard>(
            new ContextFormatter(
                MarketplaceRouter.QueryTreater.treat(req.body),
            ).SwapValues({
                name: 'sellers.name',
            }),
        );

        const q = ContextFactory.fromRequest(
            'sellers',
            connection('sellers'),
            req,
        )
            .SetParameters(context)
            .Build();

        Pagination.SetDefaults(context, {
            limit: DEFAULTS.PAGINATION.LIMIT,
            offset: DEFAULTS.PAGINATION.OFFSET,
        });

        if (context.limit < 0) {
            throw new BadRequestError('invalid limit');
        }
        if (context.offset < 0) {
            throw new BadRequestError('invalid offset');
        }
        /**
         * Desculpa se tem bug aqui...
         * Pode me chamar e eu vou parar qualquer coisa que to fazendo pra te ajudar.
         *    rodrigo - 11 jun 2024
         */
        return MarketplaceRouter.GetSellers(
            ContextBuilder.Make<MarketplaceSellerDashboard>(
                new ContextFormatter(
                    MarketplaceRouter.QueryTreater.treat(req.body),
                ).SwapValues({
                    name: 'sellers.name',
                }),
                MarketplaceSellerResponseObject,
            ),
            q,
            res,
        );
    }

    static async GetActiveCampaigns(req: Request, res: Response<TimeResult[]>) {
        const count = (await connection('campaigns')
            .where('marketplaceId', req.user.marketplaceId)
            .andWhere('isActive', true)
            .count('* as count')
            .andWhere('status', ItemStatus.ACTIVE)
            .first()) as { count: string | number } | undefined;

        const today = FormatDate();
        return res.json(
            [{ count: String(count?.count) || '0', date: today }],
            // count.map((item) => ({ count: String(item.count), date: today }))
        );
    }

    static async GetSellers(
        context: ContextParameters<MarketplaceSellerDashboard>,
        query: DatabaseQuery<'sellers'>,
        res: Response<SellerDashboardResponse>,
    ) {
        if (!context.orders) {
            context.orders = [{ column: 'clicks', order: 'desc' }];
        }

        if (context.orders) {
            context.orders.forEach((item) => {
                item.order = !Formatter.IsValidOrder(item.order)
                    ? item.order
                    : DEFAULTS.QUERY.ORDER;
            });
        }

        if (context.orders) {
            query.orderBy(context.orders);
        }

        const [sellers, info] = await MakeSellerDashboardQuery(
            query,
            //desculpa ae
            context as ContextParameters<MarketplaceSellerDashboard> &
                PaginationProps,
            new Pagination(context),
        );

        for (const seller of sellers) {
            seller.ctr = seller.clicks / seller.views
            seller.cr = seller.sold / seller.clicks
            Formatter.ChangeType(seller, MarketplaceSellerResponseObject);
        }

        // MarketplaceRouter.Convert(sellerData);

        return res.json({ data: sellers, info });
    }
}

const M = MarketplaceRouter;

DashboardRouter.get('/sellers', M.GetSellersFromQuery)
    .post('/sellers', M.GetSellersFromBody)
    .get('/stats/sold', Sold.GetFromQuery)
    .post('/stats/sold', Sold.GetFromBody)
    .get('/stats/clicks', Clicks.GetFromQuery)
    .post('/stats/clicks', Clicks.GetFromBody)
    .get('/stats/views', Views.GetFromQuery)
    .post('/stats/views', Views.GetFromBody)
    .get('/stats/invested', Invested.GetFromQuery)
    .post('/stats/invested', Invested.GetFromBody)
    .post('/stats/revenue', Revenue.GetFromBody)
    .get('/stats/revenue', Revenue.GetFromQuery)
    .get('/stats/campaigns', M.GetActiveCampaigns);

export type StatsResults = {
    [HTTPCodes.OK]: TimeResult[];
    [HTTPCodes.BAD_REQUEST]: string;
};

export type SellerCampaignDashboardDefs2 = Tspec.DefineApiSpec<{
    tags: ['Marketplace Campaign Dashboard'];
    security: 'jwt';
    basePath: '/api/dashboard/marketplaces/campaigns';
    paths: {
        '/sellers': {
            get: {
                responses: ApiGetStatus<{
                    200: SellerDashboardResponse;
                }>;
                summary: 'Get Sellers data based on the query';
                query: ToQuery<MarketplaceSellerDashboard>;
                handler: typeof M.GetSellersFromQuery;
            };
            post: {
                responses: ApiPostStatus<{ 200: SellerDashboardResponse[] }>;
                summary: 'Get seller data based on the body';
                handler: typeof M.GetSellersFromBody;
            };
        };
        '/stats/sold': {
            get: {
                responses: StatsResults;
                summary: 'Get sold stats for a marketplace given the filter in the query';
                handler: typeof Sold.GetFromQuery;
            };
            post: {
                responses: StatsResults;
                summary: 'Get sold status from the request body';
                handler: typeof Sold.GetFromBody;
            };
        };
        '/stats/revenue': {
            get: {
                responses: StatsResults;
                summary: 'Get revenue stats for a marketplace given the filter in the query';
                handler: typeof Revenue.GetFromQuery;
            };
            post: {
                summary: 'Get invested stats for a marketplace given the filter in the request body';
                responses: StatsResults;
                handler: typeof Invested.GetFromBody;
            };
        };
        '/stats/invested': {
            get: {
                responses: StatsResults;
                summary: 'Get invested stats for a marketplace given the filter in the query';
                handler: typeof Invested.GetFromQuery;
            };
            post: {
                summary: 'Get invested stats for a marketplace given the filter in the request body';
                responses: StatsResults;
                handler: typeof Invested.GetFromBody;
            };
        };
        '/stats/clicks': {
            get: {
                responses: StatsResults;
                summary: 'Get invested stats for a marketplace given the filter in the query';
                handler: typeof Clicks.GetFromQuery;
            };
            post: {
                responses: StatsResults;
                summary: 'Get Click stats for a marketplace given the filter in the request body';
                handler: typeof Clicks.GetFromBody;
            };
        };
        '/stats/views': {
            get: {
                responses: StatsResults;
                summary: 'Get Views stats for a marketplace given the filter in the request body';
                handler: typeof Views.GetFromQuery;
            };
            post: {
                responses: StatsResults;
                summary: 'Get invested stats for a campaign given the filter in the request body';
                handler: typeof Views.GetFromBody;
            };
        };
    };
}>;
export default DashboardRouter;
