import { Response } from 'supertest'
import { App } from '__tests__/vitest.setup'
import { TESTING_ACCESS_TOKEN } from 'src/constants'
import { HTTPCodes } from 'src/lib/ErrorHandling/ErrorHandler'
import { describe, it, expect, beforeAll } from 'vitest'
import { SellerInfo } from 'wecubedigital'

let seller: SellerInfo
let response: Response
let sellerResponse: Response

beforeAll(async () => {
    response = await App.get('/sellers')
    .set('Authorization', TESTING_ACCESS_TOKEN)

    seller = response.body[0]
    sellerResponse = await App.get(`/sellers/${seller.id}`)
    .set('Authorization', TESTING_ACCESS_TOKEN)
})

describe('Teste de rotas de seller', () => {
    it('GET - All', () => {
        expect(response.body.length).toBeGreaterThan(0)
        expect(response.status).toEqual(HTTPCodes.OK)
    })
    it('GET - One', () => {
        expect(response.body).toBeTypeOf('object')
        expect(response.status).toEqual(HTTPCodes.OK)
    })
    it('POST - Seller', async () => {
        response = await App.post('/sellers')
        .set('Authorization', TESTING_ACCESS_TOKEN)
        .send(seller)
        console.log(seller)
        expect(response.body).toBeTypeOf('object')
        expect(response.status).toEqual(HTTPCodes.OK)
    })
})