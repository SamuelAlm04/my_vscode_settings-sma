import { Response } from 'supertest'
import { App } from '__tests__/vitest.setup'
import { TESTING_ACCESS_TOKEN } from 'src/constants'
import { HTTPCodes } from 'src/lib/ErrorHandling/ErrorHandler'
import { describe, it, expect, beforeAll } from 'vitest'
import { SellerInfo, SELLERS } from 'wecubedigital'

let seller: SellerInfo
let response: Response
let sellerResponse: Response

beforeAll(async () => {
    response = await App!.get('/sellers')
    .set('Authorization', TESTING_ACCESS_TOKEN)

    seller = response.body[0]
    sellerResponse = await App!.get(`/sellers/${SELLERS.CUBE}`)
    .set('Authorization', TESTING_ACCESS_TOKEN)
})

describe('Teste de rotas de seller', () => {
    it('GET - All', () => {
        expect(response.body.length).toBeGreaterThan(0)

        expect(response.status).toEqual(HTTPCodes.OK)
    })
    it.only('GET - One', () => {
        console.log(sellerResponse)
        expect(sellerResponse.body).toBeTypeOf('object')
        expect(sellerResponse.status).toEqual(HTTPCodes.OK)
    })
    it('POST - Seller', async () => {
        response = await App!.post('/sellers')
        .set('Authorization', TESTING_ACCESS_TOKEN)
        .send(seller)

        expect(response.body).toBeTypeOf('object')
        expect(response.status).toEqual(HTTPCodes.OK)
    })
    it('PUT - Seller', async () => {
        response = await App!.put(`/sellers/${seller.id}`)
        .set('Authorization', TESTING_ACCESS_TOKEN)
        .send(seller)

        expect(response.body).toBeTypeOf('object')
        expect(response.status).toEqual(HTTPCodes.OK)
    })
    it('DELETE - Seller', async () => {
        response = await App!.delete(`/sellers/${seller.id}`)
        .set('Authorization', TESTING_ACCESS_TOKEN)

        expect(response.body).toBeTypeOf('boolean')
        expect(response.body).toEqual(true)
        expect(response.status).toEqual(HTTPCodes.OK)
    })
})
