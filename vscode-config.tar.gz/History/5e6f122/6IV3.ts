import { Response } from 'supertest'
import { App } from '__tests__/vitest.setup'
import { TESTING_ACCESS_TOKEN } from 'src/constants'
import { HTTPCodes } from 'src/lib/ErrorHandling/ErrorHandler'
import { describe, it, expect, beforeAll } from 'vitest'
import { ItemStatus, MARKETPLACES, SellerInfo, SELLERS } from 'wecubedigital'
import { connection } from 'src/db';

let response: Response

beforeAll(async () => {
    // await connection.raw('select 1 + 1')
    // await connection('sellers').update({status: ItemStatus.ACTIVE}).where('id', SELLERS.CUBE)
    response = await App!.get('/sellers')
    .set('Authorization', TESTING_ACCESS_TOKEN)

    
})

describe('Teste de rotas de seller', () => {
    it('GET - All', () => {
        expect(response.body.length).toBeGreaterThan(0)

        expect(response.status).toEqual(HTTPCodes.OK)
    })
    it.only('GET - One', async () => {
        const seller = (await connection('sellers')
    .where('id', SELLERS.CUBE)
    .andWhere('marketplaceId', MARKETPLACES.TESTING)
    .first()) as SellerInfo
        const sellerResponse = await App!.get(`sellers/${seller!.id}`)
        console.log(sellerResponse)
        expect(sellerResponse.body).toBeTypeOf('object')
        expect(sellerResponse.status).toEqual(HTTPCodes.OK)
    })
    it('POST - Seller', async () => {
        response = await App!.post('/sellers')
        .set('Authorization', TESTING_ACCESS_TOKEN)
        .send(seller)

        expect(response.body).toBeTypeOf('object')
        expect(response.status).toEqual(HTTPCodes.OK)
    })
    it('PUT - Seller', async () => {
        response = await App!.put(`/sellers/${seller.id}`)
        .set('Authorization', TESTING_ACCESS_TOKEN)
        .send(seller)

        expect(response.body).toBeTypeOf('object')
        expect(response.status).toEqual(HTTPCodes.OK)
    })
    it('DELETE - Seller', async () => {
        response = await App!.delete(`/sellers/${seller.id}`)
        .set('Authorization', TESTING_ACCESS_TOKEN)

        expect(response.body).toBeTypeOf('boolean')
        expect(response.body).toEqual(true)
        expect(response.status).toEqual(HTTPCodes.OK)
    })
})
