import { Request, Response } from 'express';
import { connection } from '../../../../../../db';
import { ContextBuilder } from '../../../../../../lib/context/ContextBuilder';
import { DashboardContextFactory } from '../../../../../../lib/context/DashboardContext';
import { Formatter } from '../../../../../../lib/Formatter';
import { ItemStatus, SELLER_FUNDS_HISTORY_TYPE } from 'wecubedigital';
import { Pagination } from '../../../../../../lib/pagination/Pagination';
import { PaginationResult } from '../../../../../../types/paginationType';
import { DateFormatter } from '../../../../../../lib/Formatter/Date';
import { DatabaseQuery } from '../../../../../../types/storageType';
import { BadRequestError } from 'src/lib/ErrorHandling/ErrorHandler';

const FinancialDateInfoObject = {
    createdAt: '2024-06-26',
    marketplaceId: 'org_2i9qNHjHfzFgrIt8lE2adETCEqU',
    sellerId: 4,
    cpc_avg: 100,
    spent: -4574500,
    applicationFee: 15000,
    addedFunds: 151365000,
};

type FinancialDate = typeof FinancialDateInfoObject;

export default async function GetDate(
    req: Request<{ date: string }>,
    res: Response<PaginationResult<FinancialDate[]>>
) {
    const timestamp = new Date(req.params.date);
    assert.ok(timestamp.getTime(), 'invalid date time', BadRequestError);
    const date = Formatter.toSqlTimeStamp(timestamp).split(' ')[0];
    const context = ContextBuilder.FromParameters(
        req.query,
        FinancialDateInfoObject
    );

    const query1 = connection('seller_funds_history')
        .select(
            'marketplaceId',
            'sellerId',
            connection.raw(
                `${DateFormatter.format(
                    connection.client,
                    'createdAt'
                )} AS createdAt`
            ),
            connection.raw('SUM(amount) AS spent')
        )
        .where('type', SELLER_FUNDS_HISTORY_TYPE.Ad)
        .andWhere('status', ItemStatus.ACTIVE)
        .groupBy(
            'sellerId',
            'marketplaceId',
            connection.raw(DateFormatter.format(connection.client, 'createdAt'))
        )
        .as('a');

    const query2 = connection('seller_funds_history')
        .select(
            'marketplaceId',
            'sellerId',
            connection.raw(
                `${DateFormatter.format(
                    connection.client,
                    'createdAt'
                )} AS createdAt`
            ),
            connection.raw('SUM(amount) AS addedFunds')
        )
        .where('type', SELLER_FUNDS_HISTORY_TYPE.CREDITS)
        .andWhere('status', ItemStatus.ACTIVE)
        .groupBy(
            'marketplaceId',
            'sellerId',
            connection.raw(DateFormatter.format(connection.client, 'createdAt'))
        )
        .as('b');
        console.log(await query2)

    // First part of UNION ALL - records present in query1
    const part1 = connection
        .select(
            connection.raw('a.marketplaceId AS marketplaceId'),
            'a.sellerId',
            'a.createdAt',
            'a.spent',
            connection.raw('IFNULL(b.addedFunds, 0) AS addedFunds')
        )
        .from(query1)
        .leftJoin(query2, function () {
            this.on('a.marketplaceId', '=', 'b.marketplaceId')
                .andOn('a.sellerId', '=', 'b.sellerId')
                .andOn('a.createdAt', '=', 'b.createdAt');
        });

    // Second part of UNION ALL - records present in query2 but not in query1
    const part2 = connection
        .select(
            'b.marketplaceId',
            'b.sellerId',
            'b.createdAt',
            connection.raw('0 AS spent'),
            'b.addedFunds'
        )
        .from(query2)
        .leftJoin(query1, function () {
            this.on('b.marketplaceId', '=', 'a.marketplaceId')
                .andOn('b.sellerId', '=', 'a.sellerId')
                .andOn('b.createdAt', '=', 'a.createdAt');
        })
        .whereNull('a.marketplaceId');

    context.orders ??= [{ column: 'createdAt', order: 'desc' }];

    const [data, info] = await new Pagination(context).Result<FinancialDate[]>(
        DashboardContextFactory.fromRequest(
            'seller_funds_history',
            connection
                .select('*')
                .from(part1.unionAll(part2).as('seller_funds_history'))
                .whereRaw(
                    `${DateFormatter.format(
                        connection.client,
                        'createdAt'
                    )} = ? `,
                    date
                ) as DatabaseQuery<'seller_funds_history'>,
            req
        )
            .SetParameters(context)
            .Build()
    );

    for (const item of data) {
        Formatter.ChangeType(item, FinancialDateInfoObject);
    }

    return res.json({ data: data, info: info });
}
