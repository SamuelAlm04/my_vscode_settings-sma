import { NextFunction, Request, Response, Router } from 'express';
import { ParamsDictionary } from 'express-serve-static-core';
import { Tspec } from 'tspec';
import {
    NewSkuInfo,
    NewSkuInfoObject,
    ProductInfo,
    RecordOperationTypes,
    RolePermission,
    SkuInfo,
    SkuInfoObject,
} from 'wecubedigital';
import { logging } from '../../Logging/Log';
import { Managers } from '../../Managers/Managers';
import {
    BadRequestError,
    InternalError,
    InvalidItemError,
    NotFoundError,
} from '../../lib/ErrorHandling/ErrorHandler';
import { Formatter } from '../../lib/Formatter';
import { ItemTreater } from '../../lib/ItemHandling/ItemTreater';
import { permissionsHandler } from '../../lib/Roles/permissionManager';
import { ContextBuilder } from '../../lib/context/ContextBuilder';
import { ContextFactory } from '../../lib/context/DatabaseContext';
import {
    ApiGetStatus,
    ApiPostStatus,
    ApiUpdateStatus,
    QueryFilter,
} from '../../types/backendTypes';
import { DatabaseQuery } from '../../types/storageType';
import {
    ItemPropertyValidator,
    KeyValueValidator,
} from '../../lib/Validation/ItemValidation/itemValidation';
import { ValidationCluster } from '../../lib/Validation/ItemValidation/ItemValidationCluster';
import { BoundsValidator } from '../../lib/Validation/ItemValidation/BoundsValidator';

export const skuRouter: Router = Router();

skuRouter.use('/', (req, res, next) =>
    permissionsHandler.validateRoute(RolePermission.SKU, req, res, next),
);

export class SkuRouterController {
    static async Param(req: Request, _: Response, next: NextFunction) {
        if (
            !('skuId' in req.params) &&
            !req.params.skuId &&
            typeof req.params.skuId !== 'string'
        ) {
            throw new BadRequestError('Sku Id must be provided');
        }

        const numberSkuId = Number(req.params.skuId);

        const skuManager = Managers.get('sku');

        if (!numberSkuId)
            return next(new BadRequestError('Sku Id Must be a number'));

        const sku = await skuManager.getById(
            numberSkuId,
            ContextFactory.fromRequest('sku', skuManager.Context(), req)
                .SetParameters(ContextBuilder.Make(req.query, SkuInfoObject))
                .Build() as DatabaseQuery<'sku'>,
        );

        if (!sku) return next(new NotFoundError('Sku not found'));

        //if (sku.marketplaceId !== req.user.marketplaceId)
        //   return next(new UnauthorizedError('Invalid MarketplaceId'));

        req.sku = sku;

        next();
    }
    static async GetSkus(req: Request, res: Response<SkuInfo[]>) {
        const skuManager = Managers.get('sku');
        const allSkus = await skuManager.getAll(
            ContextFactory.fromRequest('sku', skuManager.Context(), req)
                .SetParameters(
                    ContextBuilder.FromParameters(req.query, NewSkuInfoObject),
                )
                .Build(),
        );
        res.send(allSkus);
    }
    static GetSku(req: Request, res: Response) {
        return res.json(req.sku);
    }
    static async getSkuProduct(
        req: Request<{ skuId: string }>,
        res: Response<ProductInfo>,
    ) {
        const productManager = Managers.get('products');
        const product = await productManager.getById(
            req.sku!.productId,
            productManager.Context(),
        );

        if (!product || product.marketplaceId !== req.user.marketplaceId) {
            throw new NotFoundError(
                `Product with id ${req.sku!.productId} not found`,
            );
        }

        return res.json(product);
    }
    static async NewSku(
        req: Request<ParamsDictionary, unknown, NewSkuInfo>,
        res: Response<SkuInfo>,
    ) {
        const skuManager = Managers.get('sku');

        new ItemPropertyValidator();
        //TODO: add validation, for now just removes the unwanted values
        const validator = new ValidationCluster<
            RecordOperationTypes['new']['sku']
        >()
            .add(new ItemPropertyValidator<NewSkuInfo>())
            .add(new KeyValueValidator(NewSkuInfoObject))
            .add(new BoundsValidator(NewSkuInfoObject));

        const treater = new ItemTreater<NewSkuInfo>()
            .add((item) => {
                if ('creationDate' in item) {
                    item.creationDate = Formatter.toSqlTimeStamp(
                        item.creationDate,
                    );
                }
                return item;
            })

            .add((item) => {
                if ('videos' in item && typeof item.videos !== 'string') {
                    item.videos = JSON.stringify(item.videos);
                }
                return item;
            });

        const cleanedSku = treater.treat(
            Formatter.cleanObject<NewSkuInfo>(req.body, NewSkuInfoObject),
        );

        const hasErrors = skuManager.hasErrors(
            cleanedSku,
            NewSkuInfoObject,
            validator,
        );
        if (hasErrors?.isValid(cleanedSku)) {
            throw new InvalidItemError(validator.getErrors());
        }

        let newSku: SkuInfo | undefined;

        try {
            newSku = await skuManager.upload(cleanedSku);
        } catch (err) {
            throw new InternalError('Could not Post Sku');
        }

        if (!newSku) throw new InternalError('Could not Post Sku');

        logging.add('sku:post', { id: newSku.id, creator: req.user!.info.id });

        res.send(newSku);
    }
    static async UpdateSku(req: Request, res: Response) {
        const cleaned = Formatter.cleanObject(req.body, NewSkuInfoObject);
console.log(req.user)
        const skuManager = Managers.get('sku');

        const hasErrors = skuManager.hasErrors(
            cleaned,
            NewSkuInfoObject,
            new ItemPropertyValidator(),
        );
        if (hasErrors) {
            throw new InvalidItemError(hasErrors.getErrors());
        }
        if (!cleaned.videos) {
            //@ts-expect-error this is a valid check
            delete cleaned.videos;
        }

        const skus = await skuManager.update(req.sku!.id, cleaned);

        if (!skus) throw new InternalError('Could not Update Sku');

        logging.add('sku:put', { id: skus.id, creator: req.user!.info.id });

        return res.send(skus);
    }
    static async DeleteSku(req: Request, res: Response) {
        const isDeleted = await Managers.get('sku').hide(req.sku!.id);
        logging.add('sku:delete', {
            id: req.sku!.id,
            creator: req.user!.info.id,
        });
        return res.send(isDeleted);
    }
}

export type SkuDefs2 = Tspec.DefineApiSpec<{
    tags: ['Sku'];
    security: 'jwt';
    basePath: '/skus';
    paths: {
        '/': {
            get: {
                responses: ApiGetStatus<{ 200: SkuInfo[] }>;
                summary: 'Get Skus';
                handler: typeof SkuRouterController.GetSkus;
                query: QueryFilter<
                    Omit<
                        SkuInfo,
                        | 'rewardValue'
                        | 'weightKg'
                        | 'weight'
                        | 'width'
                        | 'height'
                        | 'modalType'
                        | 'length'
                        | 'videos'
                    >
                >;
            };
            post: {
                summary: 'Create a new Sku';
                responses: ApiPostStatus<{ 200: SkuInfo }>;
                handler: typeof SkuRouterController.NewSku;
            };
        };
        '/{skuId}': {
            get: {
                handler: typeof SkuRouterController.GetSku;
                responses: ApiGetStatus<{ 200: SkuInfo }>;
                summary: 'Get a Sku';
            };
            put: {
                summary: 'Update a Sku';
                handler: typeof SkuRouterController.UpdateSku;
                responses: ApiUpdateStatus<{ 200: SkuInfo }>;
            };
            delete: {
                summary: 'Deletes a Sku';
                handler: typeof SkuRouterController.DeleteSku;
                responses: ApiUpdateStatus<{ 200: boolean }>;
            };
        };
        '/{skuId}/products': {
            get: {
                summary: 'Get Product of a Sku';
                handler: typeof SkuRouterController.getSkuProduct;
                responses: ApiGetStatus<{ 200: ProductInfo }>;
            };
        };
    };
}>;

skuRouter.param('skuId', SkuRouterController.Param);

skuRouter.get('/', SkuRouterController.GetSkus);

skuRouter.get('/:skuId', SkuRouterController.GetSku);

skuRouter.get('/:skuId/product', SkuRouterController.getSkuProduct);

skuRouter.post('/', SkuRouterController.NewSku);

skuRouter.put('/:skuId', SkuRouterController.UpdateSku);

skuRouter.delete('/:skuId', SkuRouterController.DeleteSku);
