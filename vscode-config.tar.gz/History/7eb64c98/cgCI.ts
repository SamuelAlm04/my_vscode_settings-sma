import { Request, Response } from 'express';
import { connection } from '../../../../../../db';
import {
    ChronoQuery,
    TimeSeriesObject,
} from '../../../../../../lib/chrono/ChronoQuery';
import { BadRequestError } from '../../../../../../lib/ErrorHandling/ErrorHandler';
import { Formatter } from '../../../../../../lib/Formatter';
import { Pagination } from '../../../../../../lib/pagination/Pagination';
import { SELLER_FUNDS_HISTORY_TYPE } from 'wecubedigital';
import { DashboardContextFactory } from '../../../../../../lib/context/DashboardContext';
import { DateFormatter } from '../../../../../../lib/Formatter/Date';

const returnItem = {
    amount: 10000.0,
    sellerId: 4,
    marketplaceId: 'org_2i9qNHjHfzFgrIt8lE2adETCEqU',
    createdAt: '28-06-2024',
};

export default async function GetAddedFunds(req: Request, res: Response) {
    const chrono = new ChronoQuery();

    const timeSeries = chrono.toTimeSeries(req.query);

    if (!chrono.isValid(timeSeries, TimeSeriesObject)) {
        throw new BadRequestError('Invalid time series');
    }

    const query = await new Pagination(timeSeries).Result<
        (typeof returnItem)[]
    >(
        DashboardContextFactory.fromRequest(
            'seller_funds_history',
            connection('seller_funds_history')
                .avg('amount as amount')
                .select(
                    'marketplaceId',
                    connection.raw(
                        `${DateFormatter.format(connection.client, 'createdAt')} as createdAt`,
                    ),
                )
            //     .whereRaw(
            //         `${DateFormatter.format(connection.client, 'createdAt')} >= ?`,
            //         [timeSeries.date[0]]
            //     )
            //     .whereRaw(
            //         `${DateFormatter.format(connection.client, 'createdAt')} <= ?`,
            //         [
            //             timeSeries.date[1]
            //         ]
            // )
                .where('type', SELLER_FUNDS_HISTORY_TYPE.CREDITS)
                .groupByRaw(
                    `marketplaceId, ${DateFormatter.format(connection.client, 'createdAt')}`,
                ),
            req,
        ).Build(),
    );

    for (const item of query[0]) {
        Formatter.ChangeType(item, returnItem);
    }

    return res.json({ data: query[0], info: query[1] });
}
