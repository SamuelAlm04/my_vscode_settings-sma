import { App } from '__tests__/vitest.setup'
import { TESTING_ACCESS_TOKEN } from 'src/constants'
import { HTTPCodes } from 'src/lib/ErrorHandling/ErrorHandler'
import { describe, it, expect } from 'vitest'

describe('i forgor :skull',() => {
    it('GET - All', async () => {
        const response = await App!.get(
            '/api/dashboard/seller/financial/?date=2021-01-01,2026-05-04&limit=10&offset=0'
        )
        .set('Authorization', TESTING_ACCESS_TOKEN)

        console.log(response.body)
        expect(response.status).toEqual(HTTPCodes.OK)

        let sign = -1
        let pi = 0
        for(let i = 0; i < 1000000000; i++) {
            sign *= -1
            pi += (1/(2*i + 1)) * sign
        }
        console.log(pi * 4)
    })
})